<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="bootstrap4/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Second Skin Beauty</title>
  </head>


  <body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-dark" style="background-color: #FFBBE6; border-color: #FFBBE6;">
      <nav class="navbar navbar-light">
          <a class="navbar-brand" href="index2.php">Second Skin Beauty</a>
        </nav>

        <ul class="nav justify-content">
          <form class="form-inline" >
            <input class="form-control sm-2" type="search" style="width: 600px" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline my-2 my-sm-0" type="submit" style="background-color: #FFBBE6; border-color: #FFBBE6; color: white;" >
              <img src="icon/search.png" alt="search_icon" width="20px">
          </button>
          </form>

        </ul>

        <ul class="nav justify-content">
          <li class="nav-item">
            <a class="nav-link active" href="shop2.php" style="color: white;">Belanja</a>
          </li>
        
          <li class="nav-item">
            <a class="nav-link" href="news2.php" style="color: white;">Berita</a>
          </li>
               <li class="nav-item">
            <a class="nav-link" href="logout.php" style="color: white;">Keluar</a>
          </li>
        
          <li class="nav-item">
                  <a class="nav-link" href="cart2.php"><img src="icon/cart.jpg" width="20px;"></a>
                </li>
          
        </ul>
    </nav>
    <!-- Navbar End -->

    <!-- content -->
    <body class="bg-light">
        <br><br><br>
        <div class="container">
          <div class="row">
            <div class="col-md-4 order-md-2 mb-4">
              <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Keranjang</span>
                <span class="badge badge-secondary badge-pill">3</span>
              </h4>
              <ul class="list-group mb-3">
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                  <div>
                    <h6 class="my-0">Product name</h6>
                    <small class="text-muted">Brief description</small>
                  </div>
                  <span class="text-muted">$12</span>
                </li>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                  <div>
                    <h6 class="my-0">Second product</h6>
                    <small class="text-muted">Brief description</small>
                  </div>
                  <span class="text-muted">$8</span>
                </li>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                  <div>
                    <h6 class="my-0">Third item</h6>
                    <small class="text-muted">Brief description</small>
                  </div>
                  <span class="text-muted">$5</span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span>Total</span>
                    <strong>$20</strong>
                  </li>
              </ul>
            </div>

            <div class="col-md-8 order-md-1">
              
    
                <h4 class="mb-3">Pembayaran</h4>
    
                <div class="d-block my-3" style="background-color:white">
                  <a id="Transfer">
                      Silahkan melakukan pembayaran ke rekening: <br>
                      BCA : 547816684 <br>
                      A.N : Second Skin Beauty <br>
                      <br>

                      Silahkan melakukan pembayaran 1x24 Jam. Jika melewati batas tersebut pesanan anda <br>
                      akan kami batalkan. <br>
                      Terima Kasih
                  </a>
                </div>

                <div class="row">
                  <div class="col-md-6 mb-3">
                    <label for="cc-name">Nama Pemilik Rekening</label>
                    <input type="text" class="form-control" id="cc-name" placeholder="" required="">
                    <div class="invalid-feedback">
                      Nama Pemilik Rekening Belum di Isi
                    </div>
                  </div>
                  <div class="col-md-6 mb-3">
                    <label for="cc-number">Bank Pemilik Rekening</label>
                    <input type="text" class="form-control" id="cc-number" placeholder="" required="">
                    <div class="invalid-feedback">
                      Bank Pemilik Rekening Belum di Isi
                    </div>
                  </div>
                </div>

                <hr class="mb-4">
                <button class="btn btn-primary btn-lg btn-block" type="submit">Klik untuk melanjutkan</button>
              </form>
            </div>
          </div>
          <br><br><br><br><br>
    
    </body>
    <!-- content end -->

    <!-- Footer -->
<footer class="page-footer font-small indigo">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">
  
        <!-- Grid row -->
        <div class="row">
  
        <!-- Grid column -->
        <div class="col-md-3 mx-auto">
  
            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Butuh Bantuan ?</h5>
            <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 115px;">
  
            <ul class="list-unstyled">
            <li>
                cust@ssbeauty.co.id
            </li>
            <li>
                +62 812-8975-3154
            </li>
            <li>
                <br>
                Senin - Jum'at <br>
                10:00 - 16:00 
            </li>
            </ul>
  
        </div>
  
        <!-- Grid column -->
  
        <hr class="clearfix w-100 d-md-none">
  
        <!-- Grid column -->
        <div class="col-md-3 mx-auto">
  
            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Layanan</h5>
            <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 90px;">
  
            <ul class="list-unstyled">
            <li>
                <a href="faq2.php">Tanya Jawab</a>
            </li>
       
            </ul>
  
        </div>
        <!-- Grid column -->
  
        <hr class="clearfix w-100 d-md-none">
  
        <!-- Grid column -->
        <div class="col-md-3 mx-auto">
  
            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Hubungi Kami</h5>
            <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 85px;">
  
            <ul class="list-unstyled">
            <li>
                <a href="https://www.facebook.com/" target="facebook.com"> <img src="icon/fb.png" alt="icon_fb" width="30px"></a>
                <a href="https://www.instagram.com/" target="instagram.com"> <img src="icon/instagram.png" alt="icon_fb" width="30px"></a>
                <a href="https://www.twitter.com/" target="twitter.com"> <img src="icon/twitter.png" alt="icon_fb" width="30px"></a>
            </li>
            <li>
                <br>
                <a href="aboutus2.php">Tentang Kami</a>
            </li>
            </ul>
  
        </div>
        <!-- Grid column -->
  
        </div>
        <!-- Grid row -->
  
    </div>
  
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3" style="background-color: rgb(59, 59, 59); color: white">
        Copyright &copy; Second Skin Beauty 2019
    </div>
    <!-- Copyright -->
  
    </footer>
      <!-- footer end --> 
  
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
  </html>
