<!doctype html>

<html lang="en">

  <head>

    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



    <!-- Bootstrap CSS -->

    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->

    <link rel="stylesheet" href="bootstrap4/css/bootstrap.css">

    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

    <title>Second Skin Beauty</title>

  </head>





  <body>

    <!-- Navbar Start -->

    <nav class="navbar navbar-dark" style="background-color: #FFBBE6; border-color: #FFBBE6;">

      <nav class="navbar navbar-light">

          <a class="navbar-brand" href="index.php">Second Skin Beauty</a>

        </nav>



        <ul class="nav justify-content">

          <form class="form-inline" >

            <input class="form-control sm-2" type="search" style="width: 600px" placeholder="Pencarian" aria-label="Search">

            <button class="btn btn-outline my-2 my-sm-0" type="submit" style="background-color: #FFBBE6; border-color: #FFBBE6; color: white;" >

              <img src="icon/search.png" alt="search_icon" width="20px">

          </button>

          </form>



        </ul>



        <ul class="nav justify-content">
           <li class="nav-item">
            <a class="nav-link active" href="shop.php" style="color: white;">Belanja</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="news.php" style="color: white;">Berita</a>
          </li>
        
       

          <li class="nav-item">

                  <a class="nav-link" href="cart.php"><img src="icon/cart.jpg" width="20px;"></a>

                </li>

                   <li class="nav-item">
                  <a class="nav-link" href="register.php"><img src="icon/account icon.png" width="20px;"></a>
                </li>


        </ul>

    </nav>

    <!-- Navbar End -->



    <!-- CONTENT START -->



    <br><br>



    <div class="container">

        <div class="row">

            <div class="col">

                    <p class="rounded mx-auto d-block text-center" style="font-size: 20pt; font-family: 'Raleway', sans-serif;">Berita</p><br><br>

                    <div class="media">

                          

                            <div class="media-body">

                              <h4 class="mt-0">

                                
                            Pentingnya Punya Face Cleanser Lebih dari Satu

                              </h4>

                              <p>

                                Membersihkan wajah adalah langkah paling esensial dalam perawatan kulit. Kulit wajah yang bersih maksimal 

                                akan mencegah komedo dan jerawat muncul, memberi kesan segar dan cerah pada kulit, dan membuat skincare yang 

                                dipakai selanjutnya bisa meresap lebih baik sehingga hasilnya pun lebih optimal. <br> <br>

                                Makanya, kita nggak bisa cuma pakai satu face cleanser saja, seperti misalnya hanya mengandalkan facial wash atau micellar water. 

                                Dual cleansing bisa jadi merupakan sesuatu yang basic dalam skincare regime, karena sering kali satu langkah saja tidak cukup 

                                dalam mengangkat semua kotoran, minyak, dan sisa makeup pada wajah. <br> <br>

                                Dalam dual cleansing, ada dua jenis face cleanser yang digunakan. Pertama adalah cleansing oil yang mampu “melelehkan” makeup lebih cepat,

                                 bahkan yang waterproof sekalipun. Bila kamu merasa kulitmu terlalu berminyak dan nggak suka dengan tekstur cleansing oil, kamu bisa

                                  menggunakan cleansing water, micellar water, atau makeup remover untuk langkah pertama. Langkah keduanya? Gunakan facial wash yang

                                   akan membersihkan sisa-sisa dari langkah pertama. Bagi kulit sensitif, bisa memilih facial wash yang sudah berbentuk foam karena biasanya 

                                   lebih lembut dibandingkan yang liquid yang harus dibusakan sendiri. Setelahnya, kulit jadi ekstra bersih dan siap dibubuhkan produk skincare 

                                   lainnya seperti toner, essence, serum, moisturizer, dan sunscreen. <br> <br>

                                   Nah, uniknya, kondisi kulit kita bisa berubah kapan saja, sesuai dengan cuaca, hormon, dan kegiatan sehari-hari. Jadi sebenarnya, 

                                   face cleanser yang kita miliki sebaiknya beragam, untuk bisa menyesuaikan perubahan tersebut. <br> <br>

                                   Misalnya, kulit saya jenisnya kombinasi. Tapi ada kalanya terasa lebih berminyak dan berjerawat terutama saat PMS. Jadi, di saat-saat itu

                                  saya lebih menggunakan cleansing water atau makeup remover yang bertekstur lotion ringan (milky) untuk langkah pertama dalam dual cleansing. 

                                  Produk cleanser tanpa kandungan minyak juga saya pakai ketika sedang menggunakan eyelash extension, supaya nggak mudah rusak. Cleansing oil 

                                  atau cleansing balm biasanya saya pakai saat menggunakan makeup berat dan saat kulit terasa lebih kering. Saat traveling, saya memilih memakai 

                                  makeup remover yang terdiri dari kandungan air dan minyak yang efektif mengangkat makeup dan kotoran tapi nggak bikin kulit kering. Lalu, saya 

                                  lanjutkan dengan facial wash agar lebih segar dan bersih total. Facial scrub saya gunakan dua kali seminggu untuk mengeksfoliasi sel-sel kulit mati. <br> <br>

                                  Apa jadinya kalau hanya pakai satu facial wash setiap hari? Tentu kamu akan kerepotan mengangkat makeup karena facial wash saja sulit untuk mengangkat 

                                  tuntas semua riasan, terutama di daerah mata. Kalau pakai facial scrub setiap hari, kulit bisa iritasi, kering, dan pori-pori jadi lebih terbuka atau membesar.

                                   Kalau pakai cleansing oil saja, makeup remover saja, atau micellar water saja setiap hari, kita jadi nggak tahu bahwa ada produk lainnya yang bisa lebih sesuai 

                                   dengan kondisi kulit di saat-saat tertentu.

                              </p>
                              <br>
                              <br>

                            </div>

                          </div>

                          

                          <div class="media">

                                

                                <div class="media-body">

                                  <h4 class="mt-0">

                                    5 Produk Baru Bulan Maret dari Brand Lokal

                                  </h4>

                                  <p>

                                    <h5>

                                      Rollover Reaction Cushion Compact

                                    </h5>

                                    Kalau tiga tahun lalu brand Rollover Reaction hanya menghadirkan produk-produk untuk lip cream matte dan cream blush, tahun ini akhirnya RR akan launching 

                                    produk complexion pertamanya nanti tanggal 25 Maret 2019! Yes, bulan Maret ini RR akan menghadirkan Cushion Compact dalam tiga warna yang berbeda! Kira-kira 

                                    dengan tiga warna ini sudah cukup belum ya, untuk mewakili semua warna kulit perempuan Indonesia? Kita lihat nanti saat produk ini launching empat hari lagi. <br> <br>

                                    <h5>

                                      Luxcrime Turmeric Jasmine Mud Mask

                                    </h5>

                                    Di bulan Maret ini, brand Luxcrime memperkenalkan mud mask terbarunya dengan kandungan kunyit dan bunga jasmin. Sebelumnya brand ini sudah memiliki mud mask lainnya, 

                                    yaitu Charcoal Mint Mud Mask yang fungsinya untuk mendetoks kulit dan memberishkan pori-pori. Sedangkan Turmeric Jasmine Mud Mask, berfungsi untuk mencerahkan warna 

                                    kulit yang kusam dan membantu mencerahakan kantung mata yang gelap. Jadi, kalau kalian lagi mencari mud musk yang bisa melembapkan dan mencerahkan, rasanya ini pilihan yang tepat. <br> <br>

                                    <h5>

                                      Votre Peau Moisture retaining Coco Jelly Facial Cleanser

                                    </h5>

                                    Akhirnya brand Votre Peau punya face cleanser juga. Face cleanser yang satu ini diformulasikan untuk kulit kering/normal, yang cenderung sensitif. Dengan kandungan coco betaine dan ekstrak 

                                    minyak kelapa, cleanser ini mampu untuk membersihkan kotoran dan minyak berlebih pada wajah, tanpa merusak kelembapan alami pada kulit. Kalau kamu suka dengan rangkaian skincare dari Votre Peau, 

                                    kamu wajib sih coba produk terbarunya ini. <br> <br>

                                    <h5>

                                      Rosé All Day – Instant Rosé Face Palette 

                                    </h5>

                                    Setelah mengeluarkan lipstick, foundation dan terakhir sponge makeup, akhirnya brand ini menghadirkan face palette. Di dalam Instant Rosé Face Palette ini terdapat highlighter, blush on dan contour. 

                                    Hadir dalam dua warna berbeda, Moonlight Dreamer yang cocok dipakai oleh skin tone light to medium, dan Sun Slayer yang pas dipakai untuk kulit medium – sawo matang. Kemasannya yang compact bikin face 

                                    palette ini pas dibawa untuk traveling. <br> <br>

                                    <h5>

                                      Nood Cosmetics Browmance

                                    </h5>

                                    Rasanya pensil alis menjadi produk hot selanjutnya di antara brand-brand lokal. Nood cosmetics baru saja rilis pensil alis yang disebut Browmance. Hadir dalam dua pilihan warna Kiss My Ash dan Brown with Love yang berwarna cokelat gelap, 

                                    sehingga cocok dipakai oleh skin tone perempuan Indonesia. Tekstur eye brow pencil ini creamy dan juga lembut, memudahkan kita untuk menggambar alis.

                                  </p>


                                </div>

                              </div>

            </div>

        </div>

    </div>



    <!-- CONTENT END -->





       <!-- footer start -->

        <!-- Footer -->

        <footer class="page-footer font-small indigo">



        <!-- Footer Links -->

        <div class="container text-center text-md-left">



            <!-- Grid row -->

            <div class="row">



            <!-- Grid column -->

            <div class="col-md-3 mx-auto">



                <!-- Links -->

                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Butuh bantuan?</h5>

                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 115px;">



                <ul class="list-unstyled">

                <li>

                    cust@ssbeauty.co.id

                </li>

                <li>

                    +62 812-8975-3154

                </li>

                <li>

                    <br>

                    Monday - Friday <br>

                    10:00 AM - 16:00 PM

                </li>

                </ul>



            </div>



            <!-- Grid column -->



            <hr class="clearfix w-100 d-md-none">



            <!-- Grid column -->

            <div class="col-md-3 mx-auto">



                <!-- Links -->

                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Layanan</h5>

                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 90px;">



                <ul class="list-unstyled">

                <li>

                    <a href="faq.php">Tanya jawab</a>

                </li>

             
                </ul>



            </div>

            <!-- Grid column -->



            <hr class="clearfix w-100 d-md-none">



            <!-- Grid column -->

            <div class="col-md-3 mx-auto">



                <!-- Links -->

                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Temukan kami</h5>

                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 85px;">



                <ul class="list-unstyled">

                <li>

                    <a href="https://www.facebook.com/" target="_blank"> <img src="icon/fb.png" alt="icon_fb" width="30px"></a>

                    <a href="https://www.instagram.com/" target="_blank"> <img src="icon/instagram.png" alt="icon_fb" width="30px"></a>

                    <a href="https://www.twitter.com/" target="_blank"> <img src="icon/twitter.png" alt="icon_fb" width="30px"></a>

                </li>

                <li>

                    <br>

                    <a href="aboutus.php">Tentang kami</a>

                </li>

                </ul>



            </div>

            <!-- Grid column -->



            </div>

            <!-- Grid row -->



        </div>



        <!-- Copyright -->

        <div class="footer-copyright text-center py-3" style="background-color: rgb(59, 59, 59); color: white">

            Copyright &copy; Second Skin Beauty 2019

        </div>

        <!-- Copyright -->



        </footer>

            <!-- footer end --> 



    <!-- Optional JavaScript -->

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  </body>

</html>