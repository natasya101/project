<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="bootstrap4/css/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <title>Second Skin Beauty</title>
  </head>


  <body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-dark" style="background-color: #FFBBE6; border-color: #FFBBE6;">
      <nav class="navbar navbar-light">
          <a class="navbar-brand" href="index.php">Second Skin Beauty</a>
        </nav>

        <ul class="nav justify-content">
          <form class="form-inline" >
            <input class="form-control sm-2" type="search" style="width: 600px" placeholder="Pencarian" aria-label="Search">
            <button class="btn btn-outline my-2 my-sm-0" type="submit" style="background-color: #FFBBE6; border-color: #FFBBE6; color: white;" >
              <img src="icon/search.png" alt="search_icon" width="20px">
          </button>
          </form>

        </ul>

        <ul class="nav justify-content">
          <li class="nav-item">
            <a class="nav-link active" href="shop.php" style="color: white;">Belanja</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="news.php" style="color: white;">Berita</a>
          </li>
          <li class="nav-item">
                  <a class="nav-link" href="cart.php"><img src="icon/cart.jpg" width="20px;"></a>
                </li>
          <li class="nav-item">
                  <a class="nav-link" href="register.php"><img src="icon/account icon.png" width="20px;"></a>
                </li>
        </ul>
    </nav>
    <!-- Navbar End -->

    <div class="container">
            <div class="row">
              <div class="col-sm">
                <div class="card">
                  <div class="card-body" href="index.html">
                    <img src="Image/best seller 2.jpg" class="rounded mx-auto d-block" style="width:200px;"><br>
                    Benefit Cosmetic <br>
                    meet the professional <br>
                    Rp 130.000,00 <br>
                    <a href="produk1.php"><button type="button" class="btn btn-outline-secondary">Beli</button></a>
                  </div>
                </div>
              </div>
              <div class="col-sm">
                <div class="card">
                  <div class="card-body" >
                    <img src="Image/best seller 3.jpg" class="rounded mx-auto d-block" style="width: 200px;"><br>
                    Benefit Cosmetic <br>
                    meet the professional <br>
                    Rp 130.000,00 <br>
                    <a href="produk2.php"><button type="button" class="btn btn-outline-secondary" href="produk2.html">Beli</button></a>
                  </div>
                </div>
              </div>
            </div>

    <!-- footer start -->
<!-- Footer -->
<footer class="page-footer font-small indigo">

        <!-- Footer Links -->
        <div class="container text-center text-md-left">
      
            <!-- Grid row -->
            <div class="row">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Butuh bantuan?</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 115px;">
      
                <ul class="list-unstyled">
                <li>
                    cust@ssbeauty.co.id
                </li>
                <li>
                    +62 812-8975-3154
                </li>
                <li>
                    <br>
                    Senin - Jumat <br>
                    10:00 - 16:00 WIB
                </li>
                </ul>
      
            </div>
      
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Layanan</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 90px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="faq.php">Tanya jawab</a>
                </li>
            
                </ul>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Temukan kami</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 85px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="https://www.facebook.com/" target="facebook.com"> <img src="icon/fb.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.instagram.com/" target="instagram.com"> <img src="icon/instagram.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.twitter.com/" target="twitter.com"> <img src="icon/twitter.png" alt="icon_fb" width="30px"></a>
                </li>
                <li>
                    <br>
                    <a href="aboutus.php">Tentang kami</a>
                </li>
                </ul>
      
            </div>
            <!-- Grid column -->
      
            </div>
            <!-- Grid row -->
      
        </div>
      
        <!-- Copyright -->
        <div class="footer-copyright text-center py-3" style="background-color: rgb(59, 59, 59); color: white">
            Copyright &copy; Second Skin Beauty 2019
        </div>
        <!-- Copyright -->
      
        </footer>
          <!-- footer end --> 
      
          <!-- Optional JavaScript -->
          <!-- jQuery first, then Popper.js, then Bootstrap JS -->
          <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        </body>
      </html>