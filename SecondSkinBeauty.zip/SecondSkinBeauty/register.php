<?php 
      ob_start();
      session_start();
      $koneksi = new mysqli("localhost", "root", "", "secondskin");
 ?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="bootstrap4/css/bootstrap.css">
    <title>Sign Up</title>

</head>
<body>

    <!-- Navbar Start -->
    <nav class="navbar navbar-dark" style="background-color: #FFBBE6; border-color: #FFBBE6;">
        <nav class="navbar navbar-light">
            <a class="navbar-brand" href="index.php">Second Skin Beauty</a>
            </nav>
    
            <ul class="nav justify-content">
                <form class="form-inline" >
                    <input class="form-control sm-2" type="search" style="width: 600px" placeholder="Pencarian" aria-label="Search">
                    <button class="btn btn-outline my-2 my-sm-0" type="submit" style="background-color: #FFBBE6; border-color: #FFBBE6; color: white;" >
                        <img src="icon/search.png" alt="search_icon" width="20px">
                </button>
                </form>
            </ul>
    
            <ul class="nav justify-content">
            <li class="nav-item">
            <a class="nav-link active" href="shop.php" style="color: white;">Belanja</a>
          </li>
    
          <li class="nav-item">
            <a class="nav-link" href="news.php" style="color: white;">Berita</a>
          </li>
          
        
            <li class="nav-item">
                    <a class="nav-link" href="cart.php"><img src="icon/cart.jpg" width="20px;"></a>
                    </li>
            <li class="nav-item">
                    <a class="nav-link" href="register.php"><img src="icon/account icon.png" width="20px;"></a>
                    </li>
            </ul>
    </nav>
    <!-- Navbar End -->

    <!-- Regist Form -->
    <div class="container mt-4 mb-4">
    <div class="card bg-light">
        <article class="card-body mx-auto" style="max-width: 400px;">
            <h4 class="card-title mt-3 text-center">Daftarkan Akunmu</h4>
            
            
            <form action="" method="POST">
            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/user.png" alt="user_icon" width="20px"> </span>
                 </div>
                <input name="NamaDepan" class="form-control mr-1" placeholder="Nama Depan" type="text" >
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/user.png" alt="user_icon" width="20px"> </span>
                </div>
                <input name="NamaBelakang" class="form-control" placeholder="Nama Belakang" type="text">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/arroba.png" alt="arroba_icon" width="20px"> </span>
                 </div>
                <input name="Email" class="form-control" placeholder="E-mail" type="email">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/telephone.png" alt="phone_icon" width="20px"> </span>
                </div>
                <select class="custom-select" style="max-width: 120px;">
                    <option selected="">+62</option>
                    <option value="1">+1</option>
                    <option value="2">+966</option>
                </select>
                <input name="NoHP" class="form-control" placeholder="Nomor HP" type="text">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/house.png" alt="house_icon" width="20px"> </span>
                </div>
                <textarea name="Alamat" id="address" cols="40" rows="1" placeholder="Alamat" class="form-control"></textarea>
                </select>
            </div> <!-- form-group end.// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/calendar.png" alt="calendar_icon" width="20px"> </span>
                    </div>
                <input name="UlangTahun" class="form-control" placeholder="Tanggal Lahir" onfocus="(this.type='date')">
            </div> <!-- form-group// -->

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/password.png" alt="passlock_icon" width="20px"> </span>
                </div>
                <input name="Password" class="form-control" placeholder="Kata sandi" type="password">
            </div> <!-- form-group// -->

             <!-- form-group// -->   

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <label>Saya setuju dengan ketentuan layanan <input type="checkbox">  </label>
                </div>
            </div> <!-- form-group// -->

            <div class="form-group">
               <input type="submit" name="Register" value="Register" class="btn btn-primary">
            </div> <!-- form-group// -->      
            <p class="text-center">Sudah punya akun? <a href="login.php">Masuk</a> </p>    

        </form>
        </article>
        </div> <!-- card.// -->
        
        </div> 
        <!--container end.//-->        
        <!-- Regist Form End -->

        <!-- Footer -->
        <footer class="page-footer font-small indigo">

        <!-- Footer Links -->
        <div class="container text-center text-md-left">
      
            <!-- Grid row -->
            <div class="row">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Butuh bantuan?</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 115px;">
      
                <ul class="list-unstyled">
                <li>
                    cust@ssbeauty.co.id
                </li>
                <li>
                    +62 812-8975-3154
                </li>
                <li>
                    <br>
                    Senin - Jumat <br>
                    10:00 - 16:00 WIB
                </li>
                </ul>
      
            </div>
      
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Layanan</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 90px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="faq.php">Tanya jawab</a>
                </li>
              
                </ul>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Temukan kami</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 85px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="https://www.facebook.com/" target="_blank"> <img src="icon/fb.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.instagram.com/" target="_blank"> <img src="icon/instagram.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.twitter.com/" target="_blank"> <img src="icon/twitter.png" alt="icon_fb" width="30px"></a>
                </li>
                <li>
                    <br>
                    <a href="aboutus.php">Tentang kami</a>
                </li>
                </ul>
      
            </div>
            <!-- Grid column -->
      
            </div>
            <!-- Grid row -->
      
        </div>
      
        <!-- Copyright -->
        <div class="footer-copyright text-center py-3" style="background-color: rgb(59, 59, 59); color: white">
            Copyright &copy; Second Skin Beauty 2019
        </div>
        <!-- Copyright -->
      
        </footer>
        <!-- Footer End --> 
</body>
</html>

<?php 

    if(isset($_POST['Register'])){
        $NamaDepan = $_POST['NamaDepan'];
        $NamaBelakang = $_POST['NamaBelakang'];
        $Email = $_POST['Email'];
        $NoHP = $_POST['NoHP'];
        $Alamat = $_POST['Alamat'];
        $UlangTahun = $_POST['UlangTahun'];
        $Password = $_POST['Password'];

          $sql = $koneksi->query("INSERT INTO user (NamaDepan, NamaBelakang, Email, NoHP, Alamat, UlangTahun, Password) values('$NamaDepan', '$NamaBelakang', '$Email', '$NoHP', '$Alamat', '$UlangTahun', '$Password')");

        ?>
            <script type="text/javascript">
                alert("Register Success");
                window.location.href="login.php";
            </script>
            <?php
    }

 ?>