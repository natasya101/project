<?php 
      ob_start();
      session_start();
      $koneksi = new mysqli("localhost", "root", "", "secondskin");

 ?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="bootstrap4/css/bootstrap.css">
    <link rel="stylesheet" href="bootstrap4/css/login-style.css">
    <title>Sign In</title>

</head>
<body>

    <div class="bg-image"></div>

    <!-- Navbar Start -->
    <nav class="navbar navbar-dark" style="background-color: #FFBBE6; border-color: #FFBBE6;">
        <nav class="navbar navbar-light">
            <a class="navbar-brand" href="index.php">Second Skin Beauty</a>
            </nav>
    
            <ul class="nav justify-content">
                <form class="form-inline" >
                    <input class="form-control sm-2" type="search" style="width: 600px" placeholder="Pencarian" aria-label="Search">
                    <button class="btn btn-outline my-2 my-sm-0" type="submit" style="background-color: #FFBBE6; border-color: #FFBBE6; color: white;" >
                        <img src="icon/search.png" alt="search_icon" width="20px">
                </button>
                </form>
            </ul>
    
            <ul class="nav justify-content">
            <li class="nav-item">
                <a class="nav-link active" href="shop.php" style="color: white;">Belanja</a>
            </li>
         
            <li class="nav-item">
                <a class="nav-link" href="news.php" style="color: white;">Berita</a>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="cart.php"><img src="icon/cart.jpg" width="20px;"></a>
                    </li>
            <li class="nav-item">
                    <a class="nav-link" href="index.php"><img src="icon/account icon.png" width="20px;"></a>
                    </li>
            </ul>
    </nav>
    <!-- Navbar End -->

    <!-- Regist Form -->
    <div class="container mt-4 mb-4" style="max-width: 400px;">
    <div class="card bg-light">
        <article class="card-body mx-auto" style="max-width: 400px;">
            <h4 class="card-title text-center mb-4 mt-1">Masuk</h4>
            <hr>
            <p class="text-success text-center">Selamat datang ke SSB!</p>
            
            <form action="" method="post">
            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/arroba.png" alt="arroba_icon" width="20px"> </span>
                 </div>
                <input name="email" class="form-control" placeholder="E-mail" type="text">
            </div> <!-- form-group// -->


            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"> <img src="icon/password.png" alt="passlock_icon" width="20px"> </span>
                </div>
                <input class="form-control" placeholder="Kata Sandi" type="password" name="password">
            </div> <!-- form-group// -->   

            <div class="form-group input-group">
                <div class="input-group-prepend">
                    <label> <input type="checkbox"> Ingat saya </label>
                </div>
            </div> <!-- form-group// -->

            <div class="form-group">
                <input type="submit" name="login"class="btn btn-primary" value="Masuk">
            </div> <!-- form-group// -->      
            <p class="text-center">Belum punya akun? <a href="register.php">Daftar sekarang</a> </p>    

        </form>
        </article>
        </div> <!-- card.// -->
        
        </div> 
        <!--container end.//-->        
        <!-- Regist Form End -->

        <!-- Footer -->
        <footer class="page-footer font-small indigo">

        <!-- Footer Links -->
        <div class="container text-center text-md-left">
      
            <!-- Grid row -->
            <div class="row">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Butuh bantuan?</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 115px;">
      
                <ul class="list-unstyled">
                <li>
                    cust@ssbeauty.co.id
                </li>
                <li>
                    +62 812-8975-3154
                </li>
                <li>
                    <br>
                    Monday - Friday <br>
                    10:00 AM - 16:00 PM
                </li>
                </ul>
      
            </div>
      
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Layanan</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 90px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="faq.php">Tanya jawab</a>
                </li>
              
                </ul>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none">
      
            <!-- Grid column -->
            <div class="col-md-3 mx-auto">
      
                <!-- Links -->
                <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Temukan kami</h5>
                <hr class="black accent-2 mb-8 mt-0 d-inline-block mx-auto" style="width: 85px;">
      
                <ul class="list-unstyled">
                <li>
                    <a href="https://www.facebook.com/" target="_blank"> <img src="icon/fb.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.instagram.com/" target="_blank"> <img src="icon/instagram.png" alt="icon_fb" width="30px"></a>
                    <a href="https://www.twitter.com/" target="_blank"> <img src="icon/twitter.png" alt="icon_fb" width="30px"></a>
                </li>
                <li>
                    <br>
                    <a href="aboutus.php">Tentang kami</a>
                </li>
                </ul>
      
            </div>
            <!-- Grid column -->
      
            </div>
            <!-- Grid row -->
      
        </div>
      
        <!-- Copyright -->
        <div class="footer-copyright text-center py-3" style="background-color: rgb(59, 59, 59); color: white">
            Copyright &copy; Second Skin Beauty 2019
        </div>
        <!-- Copyright -->
      
        </footer>
        <!-- Footer End --> 
</body>
</html>

<?php 

    if(isset($_POST['login'])){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = $koneksi->query("select * from user where email = '$email' and password = '$password'");

        $data = $sql->fetch_assoc();

        $ketemu = $sql->num_rows;

        if($ketemu == 1){
            session_start();
            header("location:index2.php");
           
        }
        else{
            ?>
            <script type="text/javascript">
                alert("Email atau kata sandi salah");
            </script>

            <?php
        }
    }



 ?>