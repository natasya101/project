﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolandMusicProject
{
    class productview
    {
        public string ProductID { get; set; }
        public string TypeName { get; set; }
        public string ProductName { get; set; }
        public string ProductPrice { get; set; }
        public string ProductStock { get; set; }
    }
}
