﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MasterProductForm : Form
    {
        public static string eks;
        
        public MasterProductForm()
        {
            InitializeComponent();
            dataLoad();
        }
        MsProduct product = new MsProduct();
        MsType type = new MsType();

        Entities db = new Entities();

        public void dataLoad() {
            var temp = (from a in db.MsProducts
                        join b in db.MsTypes on a.TypeID equals b.TypeID
                        select new
                        {
                            a.ProductID,
                            b.TypeName,
                            a.ProductName,
                            a.ProductPrice,
                            a.ProductStock
                        });
            dataGridView1.DataSource = temp.ToList();

            var temp2 = (from c in db.MsTypes
                         select 
                         
                             c.TypeName
                         );
            type_cb.Text = "--Select Type--";
            type_cb.DataSource = temp2.ToList();
        

    }


        private void MasterProductForm_Load(object sender, EventArgs e)
        {

        }

        private void insert_btn_Click(object sender, EventArgs e)
        {
            MsProduct product = new MsProduct();

            eks = "insert";
            var id_di_db = db.MsProducts.OrderByDescending(a => a.ProductID).FirstOrDefault();
            int id;
            string format;
            try
            {
                id = (Convert.ToInt32(id_di_db.ProductID.Substring(id_di_db.ProductID.Length - 3)));


            }
            catch
            {
                id = 1;
            }

            int nilai = id + 1;

            format = string.Format("PR{0:d3}", nilai);
         
            product.ProductID = format;
            name_txt.ResetText();
            price_txt.ResetText();
            stock_nud.ResetText();
            type_cb.Text = "-- Select Type --";

            name_txt.Enabled = true;
            price_txt.Enabled = true;
            stock_nud.Enabled = true;
            type_cb.Enabled = true;
           
            insert_btn.Enabled = false;
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
            save_btn.Enabled = true;
            cancel_btn.Enabled = true;


        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            eks = "update";
            
            if (dataGridView1.SelectedCells.Equals("") == true)
            {
                MessageBox.Show("Please select an user!");
            }
            else if (dataGridView1.SelectedCells.Equals("") == false)
            {

                type_cb.Text = "-- Select Type --";

                string id = "";
                name_txt.Enabled = true;
                price_txt.Enabled = true;
                stock_nud.Enabled = true;
                type_cb.Enabled = true;

                insert_btn.Enabled = false;
                update_btn.Enabled = false;
                delete_btn.Enabled = false;
                save_btn.Enabled = true;
                cancel_btn.Enabled = true;
               
              
                MsProduct product = db.MsProducts.Where(x => x.ProductID == id).FirstOrDefault();
            }

        }

        private void delete_btn_Click(object sender, EventArgs e)
        {

            if (dataGridView1.CurrentRow.Selected)
            {
                MessageBox.Show("Please select an user!");
            }
            else
            {
                var confirm = MessageBox.Show("Are you sure?", "No", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    using (Entities db = new Entities())
                    {
                        string id = productID_txt.Text;
                        MsProduct product = db.MsProducts.Where(x => x.ProductID == productID_txt.Text).FirstOrDefault();
                        db.MsProducts.Remove(product);
                        db.SaveChanges();
                        MessageBox.Show("User has been removed!");

                    }

                    dataLoad();
                    productID_txt.ResetText();
                    name_txt.ResetText();
                    price_txt.ResetText();
                    stock_nud.ResetText();
                    type_cb.Text = "-- Select Type --";
                 
                }
                else if (confirm == DialogResult.No)
                {

                }
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (name_txt.Text == "")
            {
                MessageBox.Show("Product name can't be empty");
            }
            else if (name_txt.TextLength < 5 || name_txt.TextLength > 20)
            {
                MessageBox.Show("Product name must be between 5 and 20 characters!");
            }
            else if (price_txt.Text == "")
            {
                MessageBox.Show("Product price can’t be empty!");
            }
            else if (price_txt.TextLength < 0)
            {
                MessageBox.Show("Product price must be more than 0!");
            }
            else if (stock_nud.Value < 0)
            {
                MessageBox.Show("Stock must be more than 0!");
            }
            else if (type_cb.Text == "-- Select Type --")
            {
                MessageBox.Show("Product Type must be selected!");
            }
            if (eks == "insert")
            {
                MsProduct product = new MsProduct();
                MsType type = new MsType();
                
                type = db.MsTypes.Where(x => x.TypeName == type_cb.Text).FirstOrDefault();

                var id_di_db = db.MsProducts.OrderByDescending(a => a.ProductID).FirstOrDefault();
                
                int id;
                string format;
                try
                {
                    id = (Convert.ToInt32(id_di_db.ProductID.Substring(id_di_db.ProductID.Length - 3)));


                }
                catch
                {
                    id = 1;
                }

                int nilai = id + 1;

                format = string.Format("PR{0:d3}", nilai);

                product.ProductID = format;
                product.ProductName = name_txt.Text;
                product.ProductPrice = Convert.ToInt32(price_txt.Text);
                product.ProductStock = Convert.ToInt32(stock_nud.Value);
                product.TypeID = type.TypeID;

                db.MsProducts.Add(product);
                db.SaveChanges();
                dataLoad();

                MessageBox.Show("Success!");

            }

            if (eks == "update")
            {
                MsProduct product  = new MsProduct();
                MsType type = new MsType();

                type = db.MsTypes.Where(x => x.TypeName == type_cb.Text).FirstOrDefault();
                product = db.MsProducts.Where(y => y.ProductID == productID_txt.Text).FirstOrDefault();

                product.ProductID = productID_txt.Text;
                product.ProductName = name_txt.Text;
                product.ProductPrice = Convert.ToInt32(price_txt.Text);
                product.ProductStock = Convert.ToInt32(stock_nud.Value);
                product.TypeID = type.TypeID;

                db.Entry(product).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                dataLoad();


            }

            product.ProductID = "";
            name_txt.ResetText();
            price_txt.ResetText();
            stock_nud.ResetText();
            type_cb.Text = "-- Select Type --";

            name_txt.Enabled = false;
            price_txt.Enabled = false;
            stock_nud.Enabled = false;
            type_cb.Enabled = false;
            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;

        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            productID_txt.Text = "";
            name_txt.ResetText();
            price_txt.ResetText();
            stock_nud.ResetText();
            type_cb.Text = "-- Select Type --";

            name_txt.Enabled = false;
            price_txt.Enabled = false;
            stock_nud.Enabled = false;
            type_cb.Enabled = false;

            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            productID_txt.Text = selectedRow.Cells[0].Value.ToString();
            type_cb.Text = selectedRow.Cells[1].Value.ToString();
            name_txt.Text = selectedRow.Cells[2].Value.ToString();
            price_txt.Text = selectedRow.Cells[3].Value.ToString();
            stock_nud.Value = Convert.ToInt32( selectedRow.Cells[4].Value.ToString());
        }

        private void type_cb_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}

