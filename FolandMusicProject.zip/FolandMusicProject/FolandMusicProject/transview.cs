﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolandMusicProject
{
    class transview
    {
        public string TransactionID { get; set; }
        public string UserID { get; set; }
        public string TransactionDate { get; set; }
        public string ProdutID { get; set; }
        public string Quantity { get; set; }
        
    }
}
