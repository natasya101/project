﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class BuyInstrumentsForm : Form
    {
        public static string type;
        public static string name;
        public static int price;
        public static int quantity;
        public static int totalprice;
        public static string productid;

        Entities db = new Entities();
        public BuyInstrumentsForm()
        {
            InitializeComponent();
            loadData();
        }

        public void loadData() {
            var temp = (from a in db.MsTypes
                        join b in db.MsProducts on a.TypeID equals b.TypeID
                        select new
                        {
                            b.ProductID,
                            a.TypeName,
                            b.ProductName,
                            b.ProductPrice,
                            b.ProductStock
                        });

            instruments_dgv.DataSource = temp.ToList();

        }




        private void BuyInstrumentsForm_Load(object sender, EventArgs e)
        {

        }
        /* */
        private void purchase_btn_Click(object sender, EventArgs e)
        {
            if (qty_nud.Value <= 0)
            {
                MessageBox.Show("Quantity must be more than 0!");
            }
            else if (qty_nud.Value > int.Parse(stock_txt.Text))
            {
                MessageBox.Show("Quantity can't be more than available stocks!");
            }
            else {
             var confirm = MessageBox.Show("To payment?", "Cancel", MessageBoxButtons.OKCancel);
                if (confirm == DialogResult.OK) {


                    type = type_txt.Text;
                    name = name_txt.Text;
                    quantity = Convert.ToInt32(qty_nud.Value);
                    totalprice = Convert.ToInt32(totalprice_txt.Text);
                    price = Convert.ToInt32(price_txt.Text);

                    PaymentForm newpay = new PaymentForm();

                
                    this.Hide();
                    newpay.Show();
                }
                else if (confirm == DialogResult.Cancel) {
                   
                }
            }
        }

        private void instruments_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;

            DataGridViewRow selectedRow = instruments_dgv.Rows[index];
            type_txt.Text = selectedRow.Cells[1].Value.ToString();
            name_txt.Text = selectedRow.Cells[2].Value.ToString();
            price_txt.Text = selectedRow.Cells[3].Value.ToString();
            stock_txt.Text = selectedRow.Cells[4].Value.ToString();
            productid = selectedRow.Cells[0].Value.ToString();
        }


        private void qty_nud_ValueChanged_1(object sender, EventArgs e)
        {
            int harga = int.Parse(price_txt.Text);
            int count = Convert.ToInt32(qty_nud.Value);

            totalprice_txt.Text = System.Convert.ToString(harga * count);
        }
    }
}
