﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MasterTypeForm : Form
    {
        public static string eks;
       
        public MasterTypeForm()
        {
            InitializeComponent();
            loadData();

        }


        MsType type = new MsType();
        Entities db = new Entities();

        private void loadData()
        {
            var temp = (from x in db.MsTypes select new { x.TypeID, x.TypeName });
            dataGridView1.DataSource = temp.ToList();
        }




        private void MasterTypeForm_Load(object sender, EventArgs e)
        {
        }



        private void insert_btn_Click(object sender, EventArgs e)
        {
            MsType typebaru = new MsType();

            eks = "insert";
            var id_pada_db = db.MsTypes.OrderByDescending(x => x.TypeID).FirstOrDefault();
            int id;
            string format;

            try
            {
                id = (Convert.ToInt32(id_pada_db.TypeID.Substring(id_pada_db.TypeID.Length - 3)));

            }
            catch
            {
                id = 1;
            }

            int nilai = id + 1;
            format = string.Format("TP{0:d3}", nilai);
            typebaru.TypeID = format;
            typename_txt.ResetText();
            typename_txt.Enabled = true;
            typeID_txt.Enabled = false;
            insert_btn.Enabled = false;
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
            save_btn.Enabled = true;
            cancel_btn.Enabled = true;

        }





        private void update_btn_Click(object sender, EventArgs e)
        {
            eks = "update";
            if (dataGridView1.CurrentRow.Selected == true)
            {
                MessageBox.Show("Please select an item");
            }
            else if (dataGridView1.CurrentRow.Selected != true)
            {
                string id = "";
                typename_txt.ResetText();
                typename_txt.Enabled = true;
                insert_btn.Enabled = false;
                update_btn.Enabled = false;
                delete_btn.Enabled = false;
                save_btn.Enabled = true;
                cancel_btn.Enabled = true;
                MsType type = db.MsTypes.Where(x => x.TypeID == id).FirstOrDefault();

            }

        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Selected == true)
            {
                MessageBox.Show("please select an item!");
            }
            else
            {
                var confirmation = MessageBox.Show("Are you sure?", "No", MessageBoxButtons.YesNo);
                if (confirmation == DialogResult.Yes)
                {
                    using (Entities db = new Entities())
                    {
                        string id = typeID_txt.Text;
                        MsType type = db.MsTypes.Where(x => x.TypeID == typeID_txt.Text).FirstOrDefault();
                        db.MsTypes.Remove(type);

                        db.SaveChanges();
                        MessageBox.Show("Selected type has been removed!");
                    }

                    loadData();
                    typename_txt.ResetText();


                }
                else if (confirmation == DialogResult.No)
                {

                }

            }
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            typeID_txt.Text = "";
            typename_txt.ResetText();

            typename_txt.Enabled = true;
            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (typename_txt.Text == null)
            {
                MessageBox.Show("Type name can't be empty");
            }
            else if (typeID_txt.TextLength < 5 || typeID_txt.TextLength > 15)
            {
                MessageBox.Show("Type name must be between 5 and 20 characters!");

            }

            if (eks == "insert")
            {
                MsType typebaru = new MsType();

                var id_pada_db = db.MsTypes.OrderByDescending(x => x.TypeID).FirstOrDefault();
                int id;
                string format;
                try
                {
                    id = (Convert.ToInt32(id_pada_db.TypeID.Substring(id_pada_db.TypeID.Length - 3)));
                }

                catch
                {
                    id = 1;
                }

                int nilai = id + 1;

                format = string.Format("TP{0:d3}", nilai);

                typebaru.TypeID = format;
                typebaru.TypeName = typename_txt.Text;

                db.MsTypes.Add(typebaru);
                db.SaveChanges();
                loadData();

                MessageBox.Show("Succes!");
            }

            if (eks == "update")
            {
                MsType typebaru = new MsType();
                typebaru = db.MsTypes.Where(x => x.TypeID == typeID_txt.Text).FirstOrDefault();
                typebaru.TypeName = typename_txt.Text;

                db.Entry(typebaru).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                loadData();
            }

            typename_txt.ResetText();

            typename_txt.Enabled = false;
            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != 1)
            {
                var type_id = Convert.ToString(dataGridView1.CurrentRow.Cells["typeID"].Value);


                var design = db.MsTypes.Where(x => x.TypeID == type_id).FirstOrDefault();
                typeID_txt.Text = design.TypeID;
                typename_txt.Text = design.TypeName;

            }
        }
    }
}



