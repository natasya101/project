﻿namespace FolandMusicProject
{
    partial class MasterProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.instrumentdetails_gb = new System.Windows.Forms.GroupBox();
            this.stock_nud = new System.Windows.Forms.NumericUpDown();
            this.type_cb = new System.Windows.Forms.ComboBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.price_txt = new System.Windows.Forms.TextBox();
            this.productID_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.actions_gb = new System.Windows.Forms.GroupBox();
            this.delete_btn = new System.Windows.Forms.Button();
            this.update_btn = new System.Windows.Forms.Button();
            this.insert_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.instrumentdetails_gb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock_nud)).BeginInit();
            this.actions_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(761, 237);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // instrumentdetails_gb
            // 
            this.instrumentdetails_gb.Controls.Add(this.stock_nud);
            this.instrumentdetails_gb.Controls.Add(this.type_cb);
            this.instrumentdetails_gb.Controls.Add(this.name_txt);
            this.instrumentdetails_gb.Controls.Add(this.price_txt);
            this.instrumentdetails_gb.Controls.Add(this.productID_txt);
            this.instrumentdetails_gb.Controls.Add(this.label5);
            this.instrumentdetails_gb.Controls.Add(this.label4);
            this.instrumentdetails_gb.Controls.Add(this.label3);
            this.instrumentdetails_gb.Controls.Add(this.label2);
            this.instrumentdetails_gb.Controls.Add(this.label1);
            this.instrumentdetails_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.instrumentdetails_gb.Location = new System.Drawing.Point(12, 271);
            this.instrumentdetails_gb.Name = "instrumentdetails_gb";
            this.instrumentdetails_gb.Size = new System.Drawing.Size(566, 235);
            this.instrumentdetails_gb.TabIndex = 1;
            this.instrumentdetails_gb.TabStop = false;
            this.instrumentdetails_gb.Text = "Instrument Details";
            // 
            // stock_nud
            // 
            this.stock_nud.Enabled = false;
            this.stock_nud.Location = new System.Drawing.Point(94, 180);
            this.stock_nud.Name = "stock_nud";
            this.stock_nud.Size = new System.Drawing.Size(64, 26);
            this.stock_nud.TabIndex = 9;
            // 
            // type_cb
            // 
            this.type_cb.Enabled = false;
            this.type_cb.FormattingEnabled = true;
            this.type_cb.Location = new System.Drawing.Point(368, 28);
            this.type_cb.Name = "type_cb";
            this.type_cb.Size = new System.Drawing.Size(170, 28);
            this.type_cb.TabIndex = 8;
            this.type_cb.SelectedIndexChanged += new System.EventHandler(this.type_cb_SelectedIndexChanged);
            // 
            // name_txt
            // 
            this.name_txt.Enabled = false;
            this.name_txt.Location = new System.Drawing.Point(94, 80);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(267, 26);
            this.name_txt.TabIndex = 7;
            // 
            // price_txt
            // 
            this.price_txt.Enabled = false;
            this.price_txt.Location = new System.Drawing.Point(94, 129);
            this.price_txt.Name = "price_txt";
            this.price_txt.Size = new System.Drawing.Size(267, 26);
            this.price_txt.TabIndex = 6;
            // 
            // productID_txt
            // 
            this.productID_txt.Enabled = false;
            this.productID_txt.Location = new System.Drawing.Point(118, 34);
            this.productID_txt.Name = "productID_txt";
            this.productID_txt.Size = new System.Drawing.Size(100, 26);
            this.productID_txt.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(316, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Stock";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product ID";
            // 
            // actions_gb
            // 
            this.actions_gb.Controls.Add(this.delete_btn);
            this.actions_gb.Controls.Add(this.update_btn);
            this.actions_gb.Controls.Add(this.insert_btn);
            this.actions_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.actions_gb.ForeColor = System.Drawing.Color.White;
            this.actions_gb.Location = new System.Drawing.Point(13, 527);
            this.actions_gb.Name = "actions_gb";
            this.actions_gb.Size = new System.Drawing.Size(565, 103);
            this.actions_gb.TabIndex = 2;
            this.actions_gb.TabStop = false;
            this.actions_gb.Text = "Actions";
            // 
            // delete_btn
            // 
            this.delete_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.delete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.delete_btn.Location = new System.Drawing.Point(385, 42);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(152, 42);
            this.delete_btn.TabIndex = 2;
            this.delete_btn.Text = "Delete";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.update_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.update_btn.Location = new System.Drawing.Point(208, 42);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(152, 42);
            this.update_btn.TabIndex = 1;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // insert_btn
            // 
            this.insert_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.insert_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.insert_btn.Location = new System.Drawing.Point(25, 42);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(159, 42);
            this.insert_btn.TabIndex = 0;
            this.insert_btn.Text = "Insert";
            this.insert_btn.UseVisualStyleBackColor = false;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.save_btn.Enabled = false;
            this.save_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.save_btn.Location = new System.Drawing.Point(599, 507);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(142, 58);
            this.save_btn.TabIndex = 4;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.cancel_btn.Enabled = false;
            this.cancel_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cancel_btn.Location = new System.Drawing.Point(599, 572);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(142, 58);
            this.cancel_btn.TabIndex = 5;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // MasterProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(785, 653);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.actions_gb);
            this.Controls.Add(this.instrumentdetails_gb);
            this.Controls.Add(this.dataGridView1);
            this.Name = "MasterProductForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foland Music - Master Product";
            this.Load += new System.EventHandler(this.MasterProductForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.instrumentdetails_gb.ResumeLayout(false);
            this.instrumentdetails_gb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock_nud)).EndInit();
            this.actions_gb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox instrumentdetails_gb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown stock_nud;
        private System.Windows.Forms.ComboBox type_cb;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox price_txt;
        private System.Windows.Forms.TextBox productID_txt;
        private System.Windows.Forms.GroupBox actions_gb;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Button cancel_btn;
    }
}