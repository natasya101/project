﻿namespace FolandMusicProject
{
    partial class MasterTypeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.typedetails_gb = new System.Windows.Forms.GroupBox();
            this.typename_txt = new System.Windows.Forms.TextBox();
            this.typeID_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.delete_btn = new System.Windows.Forms.Button();
            this.update_btn = new System.Windows.Forms.Button();
            this.insert_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.typedetails_gb.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(310, 255);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // typedetails_gb
            // 
            this.typedetails_gb.Controls.Add(this.typename_txt);
            this.typedetails_gb.Controls.Add(this.typeID_txt);
            this.typedetails_gb.Controls.Add(this.label2);
            this.typedetails_gb.Controls.Add(this.label1);
            this.typedetails_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.typedetails_gb.Location = new System.Drawing.Point(13, 284);
            this.typedetails_gb.Name = "typedetails_gb";
            this.typedetails_gb.Size = new System.Drawing.Size(309, 153);
            this.typedetails_gb.TabIndex = 1;
            this.typedetails_gb.TabStop = false;
            this.typedetails_gb.Text = "Type Details";
            // 
            // typename_txt
            // 
            this.typename_txt.Enabled = false;
            this.typename_txt.Location = new System.Drawing.Point(129, 95);
            this.typename_txt.Name = "typename_txt";
            this.typename_txt.Size = new System.Drawing.Size(162, 26);
            this.typename_txt.TabIndex = 4;
            // 
            // typeID_txt
            // 
            this.typeID_txt.Enabled = false;
            this.typeID_txt.Location = new System.Drawing.Point(129, 43);
            this.typeID_txt.Name = "typeID_txt";
            this.typeID_txt.Size = new System.Drawing.Size(100, 26);
            this.typeID_txt.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Type Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Type ID";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.delete_btn);
            this.groupBox1.Controls.Add(this.update_btn);
            this.groupBox1.Controls.Add(this.insert_btn);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(340, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(271, 309);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Actions";
            // 
            // delete_btn
            // 
            this.delete_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.delete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.delete_btn.ForeColor = System.Drawing.Color.White;
            this.delete_btn.Location = new System.Drawing.Point(43, 205);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(189, 50);
            this.delete_btn.TabIndex = 2;
            this.delete_btn.Text = "Delete";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.update_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.update_btn.ForeColor = System.Drawing.Color.White;
            this.update_btn.Location = new System.Drawing.Point(43, 126);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(189, 50);
            this.update_btn.TabIndex = 1;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // insert_btn
            // 
            this.insert_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.insert_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.insert_btn.ForeColor = System.Drawing.Color.White;
            this.insert_btn.Location = new System.Drawing.Point(43, 45);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(189, 50);
            this.insert_btn.TabIndex = 0;
            this.insert_btn.Text = "Insert";
            this.insert_btn.UseVisualStyleBackColor = false;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.cancel_btn.Enabled = false;
            this.cancel_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cancel_btn.ForeColor = System.Drawing.Color.Black;
            this.cancel_btn.Location = new System.Drawing.Point(340, 397);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(136, 40);
            this.cancel_btn.TabIndex = 3;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.save_btn.Enabled = false;
            this.save_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.save_btn.ForeColor = System.Drawing.Color.Black;
            this.save_btn.Location = new System.Drawing.Point(482, 397);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(129, 40);
            this.save_btn.TabIndex = 4;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // MasterTypeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(642, 484);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.typedetails_gb);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.Name = "MasterTypeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foland Music - Master Type";
            this.Load += new System.EventHandler(this.MasterTypeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.typedetails_gb.ResumeLayout(false);
            this.typedetails_gb.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox typedetails_gb;
        private System.Windows.Forms.TextBox typename_txt;
        private System.Windows.Forms.TextBox typeID_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Button save_btn;
    }
}