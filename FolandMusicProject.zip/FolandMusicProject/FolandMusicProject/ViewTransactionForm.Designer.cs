﻿namespace FolandMusicProject
{
    partial class ViewTransactionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.transaction_dgv = new System.Windows.Forms.DataGridView();
            this.transactiondetails_gb = new System.Windows.Forms.GroupBox();
            this.date_dtp = new System.Windows.Forms.DateTimePicker();
            this.address_txt = new System.Windows.Forms.TextBox();
            this.productID_txt = new System.Windows.Forms.TextBox();
            this.productname_txt = new System.Windows.Forms.TextBox();
            this.producttype_txt = new System.Windows.Forms.TextBox();
            this.productprice_txt = new System.Windows.Forms.TextBox();
            this.qty_txt = new System.Windows.Forms.TextBox();
            this.userID_txt = new System.Windows.Forms.TextBox();
            this.customername_txt = new System.Windows.Forms.TextBox();
            this.phonenumber_txt = new System.Windows.Forms.TextBox();
            this.transactionID_txt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.transaction_dgv)).BeginInit();
            this.transactiondetails_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // transaction_dgv
            // 
            this.transaction_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.transaction_dgv.Location = new System.Drawing.Point(73, 12);
            this.transaction_dgv.Name = "transaction_dgv";
            this.transaction_dgv.RowTemplate.Height = 24;
            this.transaction_dgv.Size = new System.Drawing.Size(642, 265);
            this.transaction_dgv.TabIndex = 0;
            this.transaction_dgv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.transaction_dgv_MouseClick_1);
            // 
            // transactiondetails_gb
            // 
            this.transactiondetails_gb.Controls.Add(this.date_dtp);
            this.transactiondetails_gb.Controls.Add(this.address_txt);
            this.transactiondetails_gb.Controls.Add(this.productID_txt);
            this.transactiondetails_gb.Controls.Add(this.productname_txt);
            this.transactiondetails_gb.Controls.Add(this.producttype_txt);
            this.transactiondetails_gb.Controls.Add(this.productprice_txt);
            this.transactiondetails_gb.Controls.Add(this.qty_txt);
            this.transactiondetails_gb.Controls.Add(this.userID_txt);
            this.transactiondetails_gb.Controls.Add(this.customername_txt);
            this.transactiondetails_gb.Controls.Add(this.phonenumber_txt);
            this.transactiondetails_gb.Controls.Add(this.transactionID_txt);
            this.transactiondetails_gb.Controls.Add(this.label13);
            this.transactiondetails_gb.Controls.Add(this.label12);
            this.transactiondetails_gb.Controls.Add(this.label11);
            this.transactiondetails_gb.Controls.Add(this.label10);
            this.transactiondetails_gb.Controls.Add(this.label9);
            this.transactiondetails_gb.Controls.Add(this.label8);
            this.transactiondetails_gb.Controls.Add(this.label7);
            this.transactiondetails_gb.Controls.Add(this.label6);
            this.transactiondetails_gb.Controls.Add(this.label5);
            this.transactiondetails_gb.Controls.Add(this.label3);
            this.transactiondetails_gb.Controls.Add(this.label2);
            this.transactiondetails_gb.Controls.Add(this.label1);
            this.transactiondetails_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.transactiondetails_gb.Location = new System.Drawing.Point(13, 303);
            this.transactiondetails_gb.Name = "transactiondetails_gb";
            this.transactiondetails_gb.Size = new System.Drawing.Size(786, 315);
            this.transactiondetails_gb.TabIndex = 1;
            this.transactiondetails_gb.TabStop = false;
            this.transactiondetails_gb.Text = "Transaction Details";
            // 
            // date_dtp
            // 
            this.date_dtp.Enabled = false;
            this.date_dtp.Location = new System.Drawing.Point(489, 27);
            this.date_dtp.Name = "date_dtp";
            this.date_dtp.Size = new System.Drawing.Size(269, 23);
            this.date_dtp.TabIndex = 23;
            // 
            // address_txt
            // 
            this.address_txt.Enabled = false;
            this.address_txt.Location = new System.Drawing.Point(533, 207);
            this.address_txt.Multiline = true;
            this.address_txt.Name = "address_txt";
            this.address_txt.Size = new System.Drawing.Size(195, 55);
            this.address_txt.TabIndex = 22;
            // 
            // productID_txt
            // 
            this.productID_txt.Enabled = false;
            this.productID_txt.Location = new System.Drawing.Point(139, 66);
            this.productID_txt.Name = "productID_txt";
            this.productID_txt.Size = new System.Drawing.Size(100, 23);
            this.productID_txt.TabIndex = 21;
            // 
            // productname_txt
            // 
            this.productname_txt.Enabled = false;
            this.productname_txt.Location = new System.Drawing.Point(139, 130);
            this.productname_txt.Name = "productname_txt";
            this.productname_txt.Size = new System.Drawing.Size(183, 23);
            this.productname_txt.TabIndex = 20;
            // 
            // producttype_txt
            // 
            this.producttype_txt.Enabled = false;
            this.producttype_txt.Location = new System.Drawing.Point(139, 167);
            this.producttype_txt.Name = "producttype_txt";
            this.producttype_txt.Size = new System.Drawing.Size(183, 23);
            this.producttype_txt.TabIndex = 19;
            // 
            // productprice_txt
            // 
            this.productprice_txt.Enabled = false;
            this.productprice_txt.Location = new System.Drawing.Point(139, 201);
            this.productprice_txt.Name = "productprice_txt";
            this.productprice_txt.Size = new System.Drawing.Size(183, 23);
            this.productprice_txt.TabIndex = 18;
            // 
            // qty_txt
            // 
            this.qty_txt.Enabled = false;
            this.qty_txt.Location = new System.Drawing.Point(139, 239);
            this.qty_txt.Name = "qty_txt";
            this.qty_txt.Size = new System.Drawing.Size(57, 23);
            this.qty_txt.TabIndex = 17;
            // 
            // userID_txt
            // 
            this.userID_txt.Enabled = false;
            this.userID_txt.Location = new System.Drawing.Point(489, 63);
            this.userID_txt.Name = "userID_txt";
            this.userID_txt.Size = new System.Drawing.Size(100, 23);
            this.userID_txt.TabIndex = 16;
            // 
            // customername_txt
            // 
            this.customername_txt.Enabled = false;
            this.customername_txt.Location = new System.Drawing.Point(533, 136);
            this.customername_txt.Name = "customername_txt";
            this.customername_txt.Size = new System.Drawing.Size(173, 23);
            this.customername_txt.TabIndex = 15;
            // 
            // phonenumber_txt
            // 
            this.phonenumber_txt.Enabled = false;
            this.phonenumber_txt.Location = new System.Drawing.Point(533, 173);
            this.phonenumber_txt.Name = "phonenumber_txt";
            this.phonenumber_txt.Size = new System.Drawing.Size(173, 23);
            this.phonenumber_txt.TabIndex = 14;
            // 
            // transactionID_txt
            // 
            this.transactionID_txt.Enabled = false;
            this.transactionID_txt.Location = new System.Drawing.Point(139, 27);
            this.transactionID_txt.Name = "transactionID_txt";
            this.transactionID_txt.Size = new System.Drawing.Size(100, 23);
            this.transactionID_txt.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 207);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "Product Price";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(418, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "Date";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(418, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "User ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(418, 207);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "Product ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Product Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Product Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(418, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Phone Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(202, 239);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "pcs";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(418, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Transaction ID";
            // 
            // ViewTransactionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(811, 630);
            this.Controls.Add(this.transactiondetails_gb);
            this.Controls.Add(this.transaction_dgv);
            this.Name = "ViewTransactionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foland Music - View Transaction";
            this.Load += new System.EventHandler(this.ViewTransactionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.transaction_dgv)).EndInit();
            this.transactiondetails_gb.ResumeLayout(false);
            this.transactiondetails_gb.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView transaction_dgv;
        private System.Windows.Forms.GroupBox transactiondetails_gb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox productID_txt;
        private System.Windows.Forms.TextBox productname_txt;
        private System.Windows.Forms.TextBox producttype_txt;
        private System.Windows.Forms.TextBox productprice_txt;
        private System.Windows.Forms.TextBox qty_txt;
        private System.Windows.Forms.TextBox userID_txt;
        private System.Windows.Forms.TextBox customername_txt;
        private System.Windows.Forms.TextBox phonenumber_txt;
        private System.Windows.Forms.TextBox transactionID_txt;
        private System.Windows.Forms.DateTimePicker date_dtp;
        private System.Windows.Forms.TextBox address_txt;
    }
}