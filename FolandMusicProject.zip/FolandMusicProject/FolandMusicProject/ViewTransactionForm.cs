﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class ViewTransactionForm : Form
    {
        Entities db = new Entities();

        public ViewTransactionForm()
        {
            InitializeComponent();
            loadData();

        }

        public void loadData()
        {
            var temp = (from a in db.HeaderTransactions
                        join b in db.DetailTransactions
on a.TransactionID equals b.TransactionID
                        join c in db.MsProducts
on b.ProductID equals c.ProductID
                        select new
                        {
                            a.TransactionID,
                            a.UserID,
                            a.TransactionDate,
                            b.ProductID,
                            b.Quantity

                        });
            transaction_dgv.DataSource = temp.ToList();


        }


      
        private void ViewTransactionForm_Load(object sender, EventArgs e)
        {

             
        }

        private void transaction_dgv_MouseClick_1(object sender, MouseEventArgs e)
        {
            if (transaction_dgv.CurrentRow.Index != -1)
            {
                var transactionId = Convert.ToString(transaction_dgv.CurrentRow.Cells["TransactionID"].Value);
                var productId = Convert.ToString(transaction_dgv.CurrentRow.Cells["ProductID"].Value);
                var UserId = Convert.ToString(transaction_dgv.CurrentRow.Cells["UserID"].Value);

                using (Entities db = new Entities())
                {
                    var m1 = db.HeaderTransactions.Where(x => x.TransactionID == transactionId).FirstOrDefault();
                    var m2 = db.DetailTransactions.Where(x => x.TransactionID == transactionId).FirstOrDefault();
                    var m3 = db.MsUsers.Where(x => x.UserID == UserId).FirstOrDefault();
                    var m4 = db.MsProducts.Where(x => x.ProductID == productId).FirstOrDefault();
                    var m5 = db.MsTypes.Where(x => x.TypeID == m4.TypeID).FirstOrDefault();
                    transactionID_txt.Text = m1.TransactionID;
                    productID_txt.Text = m2.ProductID;
                    userID_txt.Text = m1.UserID;
                    date_dtp.Value = m1.TransactionDate;
                    productname_txt.Text = m4.ProductName;
                    productprice_txt.Text = Convert.ToString(m4.ProductPrice);
                    qty_txt.Text = Convert.ToString(m2.Quantity);
                    customername_txt.Text = m3.UserName;
                    phonenumber_txt.Text = m3.UserPhone;
                    address_txt.Text = m3.UserAddress;
                    producttype_txt.Text = m5.TypeName;
                }
            }
        }
    }
}