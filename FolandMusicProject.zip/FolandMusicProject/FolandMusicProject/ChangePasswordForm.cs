﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class ChangePasswordForm : Form
    {
        public ChangePasswordForm()
        {
            InitializeComponent();
        }

        Entities db = new Entities();

        private void ChangePasswordForm_Load(object sender, EventArgs e)
        {

        }
      


        private void changepass_btn_Click(object sender, EventArgs e)
        {
            string oldpassword = oldpassword_txt.Text;

            MsUser user = db.MsUsers.Where(x => x.UserID == MemberLoginForm.iduser).FirstOrDefault();

            if (oldpassword == "")
            {
                MessageBox.Show("Old password can’t be empty!");
            }
            else if (oldpassword != user.UserPassword)
            {
                MessageBox.Show("Incorrect old password!");
                oldpassword_txt.ResetText();
                newpass_txt.ResetText();
                confpass_txt.ResetText();
            }
            else if (newpass_txt.Text == "")
            {
                MessageBox.Show("New password can’t be empty!");
            }
            else if (newpass_txt.Text == oldpassword_txt.Text)
            {
                MessageBox.Show("New password can’t be the same as old password!");
            }
            else if (newpass_txt.TextLength < 6 || newpass_txt.TextLength > 15)
            {
                MessageBox.Show("Password must be between 6 and 15 characters!");
            }
            else if (confpass_txt.Text != newpass_txt.Text)
            {
                MessageBox.Show("Confirm password doesn’t match!");
            }
            else if(user != null) {

                user.UserPassword = newpass_txt.Text;               
                db.SaveChanges();
                MessageBox.Show("Change Password Success!");
                MessageBox.Show("Please re-login to update your password!");
                this.Close();
            }
        }
    }
}
