﻿namespace FolandMusicProject
{
    partial class ChangePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.confpass_txt = new System.Windows.Forms.TextBox();
            this.oldpassword_txt = new System.Windows.Forms.TextBox();
            this.newpass_txt = new System.Windows.Forms.TextBox();
            this.changepass_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(66, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Old Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(66, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "New Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(65, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Confirm Password";
            // 
            // confpass_txt
            // 
            this.confpass_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.confpass_txt.Location = new System.Drawing.Point(225, 120);
            this.confpass_txt.Name = "confpass_txt";
            this.confpass_txt.Size = new System.Drawing.Size(163, 26);
            this.confpass_txt.TabIndex = 3;
            // 
            // oldpassword_txt
            // 
            this.oldpassword_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.oldpassword_txt.Location = new System.Drawing.Point(225, 31);
            this.oldpassword_txt.Name = "oldpassword_txt";
            this.oldpassword_txt.Size = new System.Drawing.Size(163, 26);
            this.oldpassword_txt.TabIndex = 4;
            // 
            // newpass_txt
            // 
            this.newpass_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.newpass_txt.Location = new System.Drawing.Point(225, 76);
            this.newpass_txt.Name = "newpass_txt";
            this.newpass_txt.Size = new System.Drawing.Size(163, 26);
            this.newpass_txt.TabIndex = 5;
            // 
            // changepass_btn
            // 
            this.changepass_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.changepass_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.changepass_btn.ForeColor = System.Drawing.Color.White;
            this.changepass_btn.Location = new System.Drawing.Point(69, 172);
            this.changepass_btn.Name = "changepass_btn";
            this.changepass_btn.Size = new System.Drawing.Size(319, 38);
            this.changepass_btn.TabIndex = 6;
            this.changepass_btn.Text = "Change Password";
            this.changepass_btn.UseVisualStyleBackColor = false;
            this.changepass_btn.Click += new System.EventHandler(this.changepass_btn_Click);
            // 
            // ChangePasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(427, 234);
            this.Controls.Add(this.changepass_btn);
            this.Controls.Add(this.newpass_txt);
            this.Controls.Add(this.oldpassword_txt);
            this.Controls.Add(this.confpass_txt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ChangePasswordForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change Password";
            this.Load += new System.EventHandler(this.ChangePasswordForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox confpass_txt;
        private System.Windows.Forms.TextBox oldpassword_txt;
        private System.Windows.Forms.TextBox newpass_txt;
        private System.Windows.Forms.Button changepass_btn;
    }
}