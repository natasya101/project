﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MemberRegisterForm : Form
    {
        Entities db = new Entities();
        string gender;
        public MemberRegisterForm()
        {
            InitializeComponent();
        }




        private void MemberRegisterForm_Load(object sender, EventArgs e)
        {

        }

        private void register_btn_Click(object sender, EventArgs e)
        {
            DateTime date = DateTime.Parse(dob_dtp.Text);
            DateTime datenow = DateTime.Today;
            int age = datenow.Year - date.Year;






            if (name_txt.Text == "")
            {
                MessageBox.Show("Name can't be empty");
            }
            else if (name_txt.TextLength < 3 || name_txt.TextLength > 15)
            {
                MessageBox.Show("Name must be between 3 and 15 characters!");
            }
            else if (female_rbtn.Checked == false && male_rbtn.Checked == false)
            {
                MessageBox.Show("Gender must be selected");
            }



            else if (age < 10)
            {
                MessageBox.Show("You must be at least 10 years old to register!");
            }

            else if (phonenumber_txt.Text == "")
            {
                MessageBox.Show("Phone number can't be empty");
            }

            else if (phonenumber_txt.TextLength < 9)
            {
                MessageBox.Show("Phone number must be more than 9 characters");
            }

            else if (phonenumber_txt.Text.All(char.IsDigit) == false) {
                MessageBox.Show("Phone number must be numeric!");
            }



            else if (address_txt.Text == "")
            {
                MessageBox.Show("Address can't be empty");
            }

          
            else if (!this.address_txt.Text.EndsWith("Street") && !this.address_txt.Text.EndsWith("street"))
            {

                MessageBox.Show("Address must be ends with Street!");
            }

            else if (email_txt.Text == "")
            {
                MessageBox.Show("Email can’t be empty!");
            }
            //email not correct

            else if (!this.email_txt.Text.EndsWith(".com") && !this.email_txt.Text.EndsWith(".co.id"))
            {
                MessageBox.Show("Email must ends with '.com' or '.co.id'!");
            }

            else if (!email_txt.Text.Contains("@") || !email_txt.Text.Contains("."))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (email_txt.Text.EndsWith("@") && email_txt.Text.EndsWith(".")
                && email_txt.Text.StartsWith("@") && email_txt.Text.StartsWith("."))
            {
                MessageBox.Show("Email format is incorrect!");
            }
            else if (email_txt.Text.Contains("@."))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (email_txt.Text.Contains(".@"))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (password_txt.Text == "")
            {
                MessageBox.Show("Password can’t be empty!");
            }

            else if (password_txt.TextLength < 6 || password_txt.TextLength > 15)
            {
                MessageBox.Show("Password must be between 6 and 15 characters!");
            }

            else if (confirmpassword_txt.Text == "")
            {
                MessageBox.Show("Confirm password can’t be empty!");
            }

            else if (confirmpassword_txt.Text != password_txt.Text)
            {
                MessageBox.Show("Confirm password doesn’t match!");
            }

    
            else
            {

                MsUser userbaru = new MsUser();

                {
                    var id_di_db = db.MsUsers.OrderByDescending(a => a.UserID).FirstOrDefault();
                    int id;
                    string format;
                    try
                    {
                        id = (Convert.ToInt32(id_di_db.UserID.Substring(id_di_db.UserID.Length - 3)));


                    }
                    catch
                    {
                        id = 1;
                    }

                    int nilai = id + 1;

                    format = string.Format("US{0:d3}", nilai);

                    //untuk nampilin id */

                    MessageBox.Show("Success");
                    MessageBox.Show(format);
                    userbaru.UserID = format;
                    userbaru.UserRole = "Member";
                    userbaru.UserName = name_txt.Text;
                    userbaru.UserEmail = email_txt.Text;
                    userbaru.UserPassword = password_txt.Text;
                    userbaru.UserGender = gender;
                    userbaru.UserDOB = dob_dtp.Value;
                    userbaru.UserPhone = phonenumber_txt.Text;
                    userbaru.UserAddress = address_txt.Text;


                };

                db.MsUsers.Add(userbaru);

                db.SaveChanges();
                this.Close();
            }
            }

        private void male_rbtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void female_rbtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    }

