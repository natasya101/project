﻿namespace FolandMusicProject
{
    partial class MemberRegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.password_txt = new System.Windows.Forms.TextBox();
            this.address_txt = new System.Windows.Forms.TextBox();
            this.phonenumber_txt = new System.Windows.Forms.TextBox();
            this.confirmpassword_txt = new System.Windows.Forms.TextBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.male_rbtn = new System.Windows.Forms.RadioButton();
            this.female_rbtn = new System.Windows.Forms.RadioButton();
            this.dob_dtp = new System.Windows.Forms.DateTimePicker();
            this.register_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Tan;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(33, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Member Register";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(58, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(60, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(60, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(60, 382);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(60, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date of Birth";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(374, 77);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(51, 20);
            this.Label7.TabIndex = 6;
            this.Label7.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(379, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Password";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(380, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(147, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Confirm Password";
            // 
            // email_txt
            // 
            this.email_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.email_txt.Location = new System.Drawing.Point(378, 100);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(248, 26);
            this.email_txt.TabIndex = 9;
            // 
            // password_txt
            // 
            this.password_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.password_txt.Location = new System.Drawing.Point(378, 180);
            this.password_txt.Name = "password_txt";
            this.password_txt.Size = new System.Drawing.Size(248, 26);
            this.password_txt.TabIndex = 10;
            // 
            // address_txt
            // 
            this.address_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.address_txt.Location = new System.Drawing.Point(64, 405);
            this.address_txt.Multiline = true;
            this.address_txt.Name = "address_txt";
            this.address_txt.Size = new System.Drawing.Size(246, 64);
            this.address_txt.TabIndex = 11;
            // 
            // phonenumber_txt
            // 
            this.phonenumber_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.phonenumber_txt.ForeColor = System.Drawing.Color.Black;
            this.phonenumber_txt.Location = new System.Drawing.Point(62, 325);
            this.phonenumber_txt.Name = "phonenumber_txt";
            this.phonenumber_txt.Size = new System.Drawing.Size(157, 26);
            this.phonenumber_txt.TabIndex = 12;
            // 
            // confirmpassword_txt
            // 
            this.confirmpassword_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.confirmpassword_txt.Location = new System.Drawing.Point(378, 253);
            this.confirmpassword_txt.Name = "confirmpassword_txt";
            this.confirmpassword_txt.Size = new System.Drawing.Size(248, 26);
            this.confirmpassword_txt.TabIndex = 13;
            // 
            // name_txt
            // 
            this.name_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.name_txt.Location = new System.Drawing.Point(62, 100);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(248, 26);
            this.name_txt.TabIndex = 14;
            // 
            // male_rbtn
            // 
            this.male_rbtn.AutoSize = true;
            this.male_rbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.male_rbtn.ForeColor = System.Drawing.Color.White;
            this.male_rbtn.Location = new System.Drawing.Point(62, 177);
            this.male_rbtn.Name = "male_rbtn";
            this.male_rbtn.Size = new System.Drawing.Size(66, 24);
            this.male_rbtn.TabIndex = 16;
            this.male_rbtn.TabStop = true;
            this.male_rbtn.Text = "Male";
            this.male_rbtn.UseVisualStyleBackColor = true;
            this.male_rbtn.CheckedChanged += new System.EventHandler(this.male_rbtn_CheckedChanged);
            // 
            // female_rbtn
            // 
            this.female_rbtn.AutoSize = true;
            this.female_rbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.female_rbtn.ForeColor = System.Drawing.Color.White;
            this.female_rbtn.Location = new System.Drawing.Point(134, 177);
            this.female_rbtn.Name = "female_rbtn";
            this.female_rbtn.Size = new System.Drawing.Size(85, 24);
            this.female_rbtn.TabIndex = 17;
            this.female_rbtn.TabStop = true;
            this.female_rbtn.Text = "Female";
            this.female_rbtn.UseVisualStyleBackColor = true;
            this.female_rbtn.CheckedChanged += new System.EventHandler(this.female_rbtn_CheckedChanged);
            // 
            // dob_dtp
            // 
            this.dob_dtp.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.dob_dtp.Location = new System.Drawing.Point(62, 253);
            this.dob_dtp.Name = "dob_dtp";
            this.dob_dtp.Size = new System.Drawing.Size(248, 22);
            this.dob_dtp.TabIndex = 18;
            // 
            // register_btn
            // 
            this.register_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.register_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.register_btn.ForeColor = System.Drawing.Color.White;
            this.register_btn.Location = new System.Drawing.Point(439, 310);
            this.register_btn.Name = "register_btn";
            this.register_btn.Size = new System.Drawing.Size(128, 41);
            this.register_btn.TabIndex = 19;
            this.register_btn.Text = "Register";
            this.register_btn.UseVisualStyleBackColor = false;
            this.register_btn.Click += new System.EventHandler(this.register_btn_Click);
            // 
            // MemberRegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(700, 481);
            this.Controls.Add(this.register_btn);
            this.Controls.Add(this.dob_dtp);
            this.Controls.Add(this.female_rbtn);
            this.Controls.Add(this.male_rbtn);
            this.Controls.Add(this.name_txt);
            this.Controls.Add(this.confirmpassword_txt);
            this.Controls.Add(this.phonenumber_txt);
            this.Controls.Add(this.address_txt);
            this.Controls.Add(this.password_txt);
            this.Controls.Add(this.email_txt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "MemberRegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.Load += new System.EventHandler(this.MemberRegisterForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox password_txt;
        private System.Windows.Forms.TextBox address_txt;
        private System.Windows.Forms.TextBox phonenumber_txt;
        private System.Windows.Forms.TextBox confirmpassword_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.RadioButton male_rbtn;
        private System.Windows.Forms.RadioButton female_rbtn;
        private System.Windows.Forms.DateTimePicker dob_dtp;
        private System.Windows.Forms.Button register_btn;
    }
}