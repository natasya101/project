﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MemberForm : Form
    {
        public MemberForm()
        {
            InitializeComponent();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePasswordForm changepass = new ChangePasswordForm();
            this.Hide();
            changepass.Show();
        }
        
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 menuawal = new Form1();
            this.Hide();
            menuawal.Show();
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {

        }

        private void buyInstrumentToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            BuyInstrumentsForm buyinst = new BuyInstrumentsForm();
            this.Hide();
            buyinst.Show();
        }
    }
}
