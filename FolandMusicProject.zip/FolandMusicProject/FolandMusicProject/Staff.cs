﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePasswordForm changepass = new ChangePasswordForm();
            this.Hide();
            changepass.Show();
        }

    
      

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 menuawal = new Form1();
            this.Hide();
            menuawal.Show();
        }

        private void Staff_Load(object sender, EventArgs e)
        {

        }

        private void usersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MasterUserForm masteruser = new MasterUserForm();
            this.Hide();
            masteruser.Show();
        }

       

        private void instrumentToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MasterProductForm producttt = new MasterProductForm();
            this.Hide();
            producttt.Show();
        }

        private void typeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MasterTypeForm type = new MasterTypeForm();
            this.Hide();
            type.Show();
        }

        private void viewTransactionsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ViewTransactionForm viewtrans = new ViewTransactionForm();
            this.Hide();
            viewtrans.Show();
        }
    }
}
