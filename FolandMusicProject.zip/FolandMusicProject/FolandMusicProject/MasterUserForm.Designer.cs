﻿namespace FolandMusicProject
{
    partial class MasterUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.userdetails_gb = new System.Windows.Forms.GroupBox();
            this.role_cb = new System.Windows.Forms.ComboBox();
            this.dob_dtp = new System.Windows.Forms.DateTimePicker();
            this.female_rbtn = new System.Windows.Forms.RadioButton();
            this.address_txt = new System.Windows.Forms.TextBox();
            this.male_rbtn = new System.Windows.Forms.RadioButton();
            this.phonenumber_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.userID_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.actions_gb = new System.Windows.Forms.GroupBox();
            this.insert_btn = new System.Windows.Forms.Button();
            this.delete_btn = new System.Windows.Forms.Button();
            this.update_btn = new System.Windows.Forms.Button();
            this.cancel_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.userdetails_gb.SuspendLayout();
            this.actions_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(798, 240);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // userdetails_gb
            // 
            this.userdetails_gb.Controls.Add(this.role_cb);
            this.userdetails_gb.Controls.Add(this.dob_dtp);
            this.userdetails_gb.Controls.Add(this.female_rbtn);
            this.userdetails_gb.Controls.Add(this.address_txt);
            this.userdetails_gb.Controls.Add(this.male_rbtn);
            this.userdetails_gb.Controls.Add(this.phonenumber_txt);
            this.userdetails_gb.Controls.Add(this.label6);
            this.userdetails_gb.Controls.Add(this.label5);
            this.userdetails_gb.Controls.Add(this.name_txt);
            this.userdetails_gb.Controls.Add(this.email_txt);
            this.userdetails_gb.Controls.Add(this.label7);
            this.userdetails_gb.Controls.Add(this.label4);
            this.userdetails_gb.Controls.Add(this.userID_txt);
            this.userdetails_gb.Controls.Add(this.label8);
            this.userdetails_gb.Controls.Add(this.label3);
            this.userdetails_gb.Controls.Add(this.label1);
            this.userdetails_gb.Controls.Add(this.label2);
            this.userdetails_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.userdetails_gb.Location = new System.Drawing.Point(12, 270);
            this.userdetails_gb.Name = "userdetails_gb";
            this.userdetails_gb.Size = new System.Drawing.Size(476, 389);
            this.userdetails_gb.TabIndex = 1;
            this.userdetails_gb.TabStop = false;
            this.userdetails_gb.Text = "User Details";
            // 
            // role_cb
            // 
            this.role_cb.Enabled = false;
            this.role_cb.FormattingEnabled = true;
            this.role_cb.Location = new System.Drawing.Point(308, 26);
            this.role_cb.Name = "role_cb";
            this.role_cb.Size = new System.Drawing.Size(143, 28);
            this.role_cb.TabIndex = 14;
            this.role_cb.Text = "--Select Role--";
            this.role_cb.SelectedIndexChanged += new System.EventHandler(this.role_cb_SelectedIndexChanged);
            // 
            // dob_dtp
            // 
            this.dob_dtp.Enabled = false;
            this.dob_dtp.Location = new System.Drawing.Point(152, 208);
            this.dob_dtp.Name = "dob_dtp";
            this.dob_dtp.Size = new System.Drawing.Size(299, 26);
            this.dob_dtp.TabIndex = 13;
            // 
            // female_rbtn
            // 
            this.female_rbtn.AutoSize = true;
            this.female_rbtn.Enabled = false;
            this.female_rbtn.Location = new System.Drawing.Point(245, 166);
            this.female_rbtn.Name = "female_rbtn";
            this.female_rbtn.Size = new System.Drawing.Size(85, 24);
            this.female_rbtn.TabIndex = 3;
            this.female_rbtn.TabStop = true;
            this.female_rbtn.Text = "Female";
            this.female_rbtn.UseVisualStyleBackColor = true;
            this.female_rbtn.CheckedChanged += new System.EventHandler(this.female_rbtn_CheckedChanged);
            // 
            // address_txt
            // 
            this.address_txt.Enabled = false;
            this.address_txt.Location = new System.Drawing.Point(152, 294);
            this.address_txt.Multiline = true;
            this.address_txt.Name = "address_txt";
            this.address_txt.Size = new System.Drawing.Size(238, 75);
            this.address_txt.TabIndex = 4;
            // 
            // male_rbtn
            // 
            this.male_rbtn.AutoSize = true;
            this.male_rbtn.Enabled = false;
            this.male_rbtn.Location = new System.Drawing.Point(152, 166);
            this.male_rbtn.Name = "male_rbtn";
            this.male_rbtn.Size = new System.Drawing.Size(66, 24);
            this.male_rbtn.TabIndex = 2;
            this.male_rbtn.TabStop = true;
            this.male_rbtn.Text = "Male";
            this.male_rbtn.UseVisualStyleBackColor = true;
            this.male_rbtn.CheckedChanged += new System.EventHandler(this.male_rbtn_CheckedChanged);
            // 
            // phonenumber_txt
            // 
            this.phonenumber_txt.Enabled = false;
            this.phonenumber_txt.Location = new System.Drawing.Point(152, 253);
            this.phonenumber_txt.Name = "phonenumber_txt";
            this.phonenumber_txt.Size = new System.Drawing.Size(192, 26);
            this.phonenumber_txt.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Date of Birth";
            // 
            // name_txt
            // 
            this.name_txt.Enabled = false;
            this.name_txt.Location = new System.Drawing.Point(152, 72);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(192, 26);
            this.name_txt.TabIndex = 2;
            // 
            // email_txt
            // 
            this.email_txt.Enabled = false;
            this.email_txt.Location = new System.Drawing.Point(152, 114);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(192, 26);
            this.email_txt.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 296);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Gender";
            // 
            // userID_txt
            // 
            this.userID_txt.Enabled = false;
            this.userID_txt.Location = new System.Drawing.Point(93, 28);
            this.userID_txt.Name = "userID_txt";
            this.userID_txt.Size = new System.Drawing.Size(100, 26);
            this.userID_txt.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(258, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "Role";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "User ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Name";
            // 
            // actions_gb
            // 
            this.actions_gb.Controls.Add(this.insert_btn);
            this.actions_gb.Controls.Add(this.delete_btn);
            this.actions_gb.Controls.Add(this.update_btn);
            this.actions_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.actions_gb.ForeColor = System.Drawing.Color.White;
            this.actions_gb.Location = new System.Drawing.Point(509, 270);
            this.actions_gb.Name = "actions_gb";
            this.actions_gb.Size = new System.Drawing.Size(281, 231);
            this.actions_gb.TabIndex = 2;
            this.actions_gb.TabStop = false;
            this.actions_gb.Text = "Actions";
            // 
            // insert_btn
            // 
            this.insert_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.insert_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.insert_btn.ForeColor = System.Drawing.Color.White;
            this.insert_btn.Location = new System.Drawing.Point(64, 33);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(153, 51);
            this.insert_btn.TabIndex = 3;
            this.insert_btn.Text = "Insert";
            this.insert_btn.UseVisualStyleBackColor = false;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // delete_btn
            // 
            this.delete_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.delete_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.delete_btn.ForeColor = System.Drawing.Color.White;
            this.delete_btn.Location = new System.Drawing.Point(66, 166);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(153, 51);
            this.delete_btn.TabIndex = 2;
            this.delete_btn.Text = "Delete";
            this.delete_btn.UseVisualStyleBackColor = false;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.update_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.update_btn.ForeColor = System.Drawing.Color.White;
            this.update_btn.Location = new System.Drawing.Point(66, 101);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(153, 51);
            this.update_btn.TabIndex = 1;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // cancel_btn
            // 
            this.cancel_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.cancel_btn.Enabled = false;
            this.cancel_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.cancel_btn.ForeColor = System.Drawing.Color.Black;
            this.cancel_btn.Location = new System.Drawing.Point(509, 625);
            this.cancel_btn.Name = "cancel_btn";
            this.cancel_btn.Size = new System.Drawing.Size(138, 34);
            this.cancel_btn.TabIndex = 5;
            this.cancel_btn.Text = "Cancel";
            this.cancel_btn.UseVisualStyleBackColor = false;
            this.cancel_btn.Click += new System.EventHandler(this.cancel_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.save_btn.Enabled = false;
            this.save_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.save_btn.ForeColor = System.Drawing.Color.Black;
            this.save_btn.Location = new System.Drawing.Point(653, 625);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(137, 34);
            this.save_btn.TabIndex = 6;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // MasterUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(822, 671);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.cancel_btn);
            this.Controls.Add(this.actions_gb);
            this.Controls.Add(this.userdetails_gb);
            this.Controls.Add(this.dataGridView1);
            this.Name = "MasterUserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foland Music - Master User";
            this.Load += new System.EventHandler(this.MasterUserForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.userdetails_gb.ResumeLayout(false);
            this.userdetails_gb.PerformLayout();
            this.actions_gb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox userdetails_gb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox userID_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox address_txt;
        private System.Windows.Forms.TextBox phonenumber_txt;
        private System.Windows.Forms.DateTimePicker dob_dtp;
        private System.Windows.Forms.RadioButton female_rbtn;
        private System.Windows.Forms.RadioButton male_rbtn;
        private System.Windows.Forms.GroupBox actions_gb;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Button cancel_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.ComboBox role_cb;
    }
}