﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MasterUserForm : Form
    {
        public static string eks;

        MsUser user = new MsUser();

        Entities db = new Entities();
        string gender;
        

        public MasterUserForm()
        {
            InitializeComponent();
            loadData();
        }

        public void loadData()
        {
            var temp = (from a in db.MsUsers
                        select new
                        {
                            a.UserID, a.UserRole, a.UserName, a.UserEmail, a.UserGender, 
                            a.UserDOB, a.UserPhone, a.UserAddress
                        });
            dataGridView1.DataSource = temp.ToList();

            role_cb.Text = "-- Select Role --";
            string member = "Member";
            string staff = "Staff";

            role_cb.Items.Add(member);
            role_cb.Items.Add(staff);
        }


        private void MasterUserForm_Load(object sender, EventArgs e)
        {

        }
        
        private void insert_btn_Click(object sender, EventArgs e)
        {
            MsUser userbaru = new MsUser();

            eks = "insert";
            var id_di_db = db.MsUsers.OrderByDescending(a => a.UserID).FirstOrDefault();
            int id;
            string format;
            try
            {
                id = (Convert.ToInt32(id_di_db.UserID.Substring(id_di_db.UserID.Length - 3)));


            }
            catch
            {
                id = 1;
            }

            int nilai = id + 1;

            format = string.Format("US{0:d3}", nilai);

            userbaru.UserID = format;
            //untuk nampilin id */
            userID_txt.Text = "";
            name_txt.ResetText();
            email_txt.ResetText();
            gender = "";
            dob_dtp.ResetText();
            phonenumber_txt.ResetText();
            address_txt.ResetText();
            role_cb.Text = "-- Select Role --";

            name_txt.Enabled = true;
            email_txt.Enabled = true;
            female_rbtn.Enabled = true;
            male_rbtn.Enabled = true;
            dob_dtp.Enabled = true;
            phonenumber_txt.Enabled = true;
            address_txt.Enabled = true;
            role_cb.Enabled = true;
            //userid belum
            insert_btn.Enabled = false;
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
            save_btn.Enabled = true;
            cancel_btn.Enabled = true;



        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            userID_txt.Text = "";
            name_txt.ResetText();
            email_txt.ResetText();
            gender = "";
            dob_dtp.ResetText();
            phonenumber_txt.ResetText();
            address_txt.ResetText();
            role_cb.Text = "-- Select Role --";

            name_txt.Enabled = false;
            email_txt.Enabled = false;
            female_rbtn.Enabled = false;
            male_rbtn.Enabled = false;
            dob_dtp.Enabled = false;
            phonenumber_txt.Enabled = false;
            address_txt.Enabled = false;
            role_cb.Enabled = false;
            //userid belum
            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;

        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            eks = "update";

            if (dataGridView1.SelectedCells.Equals("") == true)
             {
                MessageBox.Show("Please select an user!");
             }
            else if(dataGridView1.SelectedCells.Equals("")==false){
             
                role_cb.Text = "-- Select Role --";

                string id = "";
            name_txt.Enabled = true;
            email_txt.Enabled = true;
            female_rbtn.Enabled = true;
            male_rbtn.Enabled = true;
            dob_dtp.Enabled = true;
            phonenumber_txt.Enabled = true;
            address_txt.Enabled = true;
            role_cb.Enabled = true;

            insert_btn.Enabled = false;
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
            save_btn.Enabled = true;
            cancel_btn.Enabled = true;
                MsUser user = db.MsUsers.Where(x=>x.UserID == id).FirstOrDefault();
             }
            
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Selected)
            {
                MessageBox.Show("Please select an user!");
            }
            else{
                var confirm = MessageBox.Show("Are you sure?", "No", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    using (Entities db = new Entities()) {
                        string id = userID_txt.Text;
                        MsUser user = db.MsUsers.Where(x => x.UserID == userID_txt.Text).FirstOrDefault();
                        db.MsUsers.Remove(user);
                        db.SaveChanges();
                        MessageBox.Show("User has been removed!");

                    }

                    loadData();
                    userID_txt.ResetText();
                    name_txt.ResetText();
                    email_txt.ResetText();
                    gender = "";
                    dob_dtp.ResetText();
                    phonenumber_txt.ResetText();
                    address_txt.ResetText();
                    role_cb.Text = "-- Select Role --";
                }
                else if (confirm == DialogResult.No)
                {
                    
                }
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            DateTime date = DateTime.Parse(dob_dtp.Text);
            DateTime datenow = DateTime.Today;
            int age = datenow.Year - date.Year;

            if (name_txt.Text == "")
            {
                MessageBox.Show("Name can't be empty!");
            }
            else if (name_txt.TextLength < 3 || name_txt.TextLength > 15)
            {
                MessageBox.Show("Name must be between 3 anf 15 characters!");
            }
            else if (female_rbtn.Checked == false && male_rbtn.Checked == false)
            {
                MessageBox.Show("Gender must be selected");
            }
            else if (age < 10)
            {
                MessageBox.Show("You must be at least 10 years old to register!");
            }
            else if (phonenumber_txt.Text == "")
            {
                MessageBox.Show("Phone number can't be empty");
            }
            else if (phonenumber_txt.TextLength < 9)
            {
                MessageBox.Show("Phone number must be more than 9 characters!");
            }

            else if (phonenumber_txt.Text.All(char.IsDigit) == false)
            {
                MessageBox.Show("Phone number must be numeric!");
            }

            else if (address_txt.Text == "")
            {
                MessageBox.Show("Address can't be empty");
            }
            else if (!this.address_txt.Text.EndsWith("Street") && !this.address_txt.Text.EndsWith("street"))
            {

                MessageBox.Show("Address must be ends with Street!");
            }

            else if (email_txt.Text == "")
            {
                MessageBox.Show("Email can’t be empty!");
            }

            else if (!this.email_txt.Text.EndsWith(".com") && !this.email_txt.Text.EndsWith(".co.id"))
            {
                MessageBox.Show("Email must ends with '.com' or '.co.id'!");
            }

            else if (!email_txt.Text.Contains("@") || !email_txt.Text.Contains("."))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (email_txt.Text.EndsWith("@") && email_txt.Text.EndsWith(".")
                && email_txt.Text.StartsWith("@") && email_txt.Text.StartsWith("."))
            {
                MessageBox.Show("Email format is incorrect!");
            }
            else if (email_txt.Text.Contains("@."))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (email_txt.Text.Contains(".@"))
            {
                MessageBox.Show("Email format is incorrect!");
            }

            else if (!this.email_txt.Text.EndsWith(".com") && !this.email_txt.Text.EndsWith(".co.id"))
            {
                MessageBox.Show("Email must ends with '.com' or '.co.id'!");
            }
            else if (role_cb.Text == "-- Select Role --") {
                MessageBox.Show("Role must be selected!");
            }

            else if (role_cb.Text == "Member") {
                user.UserRole = "Member";
            }

            else if (role_cb.Text == "Staff") {
                user.UserRole = "Staff";
            }








            if (eks == "insert") {
                MsUser userbaru = new MsUser();

                var id_di_db = db.MsUsers.OrderByDescending(a => a.UserID).FirstOrDefault();
                int id;
                string format;
                try
                {
                    id = (Convert.ToInt32(id_di_db.UserID.Substring(id_di_db.UserID.Length - 3)));


                }
                catch
                {
                    id = 1;
                }

                int nilai = id + 1;

                format = string.Format("US{0:d3}", nilai);

                userbaru.UserID = format;
                userbaru.UserRole = role_cb.Text;
                userbaru.UserName = name_txt.Text;
                userbaru.UserEmail = email_txt.Text;
                userbaru.UserPassword = "default";
                userbaru.UserGender = gender;
                userbaru.UserDOB = dob_dtp.Value;
                userbaru.UserPhone = phonenumber_txt.Text;
                userbaru.UserAddress = address_txt.Text;



                db.MsUsers.Add(userbaru);
                db.SaveChanges();
                dataGridView1.DataSource = db.MsUsers.ToList();


                MessageBox.Show("Success!");

            }

            if (eks == "update") {
                MsUser userbaru = new MsUser();
                userbaru = db.MsUsers.Where(x => x.UserID == userID_txt.Text).FirstOrDefault();
                userbaru.UserName = name_txt.Text;
                userbaru.UserRole = role_cb.Text;
                userbaru.UserPhone = phonenumber_txt.Text;
                userbaru.UserDOB = dob_dtp.Value;
                userbaru.UserPassword = userbaru.UserPassword;
                userbaru.UserGender = gender;
                userbaru.UserAddress = address_txt.Text;
                userbaru.UserEmail = email_txt.Text;


                db.Entry(userbaru).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                loadData();

            }

            name_txt.ResetText();
            email_txt.ResetText();
            gender = "";
            dob_dtp.ResetText();
            phonenumber_txt.ResetText();
            address_txt.ResetText();
            role_cb.Text = "-- Select Role --";

            name_txt.Enabled = false;
            email_txt.Enabled = false;
            female_rbtn.Enabled = false;
            male_rbtn.Enabled = false;
            dob_dtp.Enabled = false;
            phonenumber_txt.Enabled = false;
            address_txt.Enabled = false;
            role_cb.Enabled = false;
            insert_btn.Enabled = true;
            update_btn.Enabled = true;
            delete_btn.Enabled = true;
            save_btn.Enabled = false;
            cancel_btn.Enabled = false;
        }

        private void role_cb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            userID_txt.Text = selectedRow.Cells[0].Value.ToString();
            role_cb.Text = selectedRow.Cells[1].Value.ToString();
            name_txt.Text = selectedRow.Cells[2].Value.ToString();
            email_txt.Text = selectedRow.Cells[3].Value.ToString();
            gender = selectedRow.Cells[4].Value.ToString();
            dob_dtp.Text = selectedRow.Cells[5].Value.ToString();
            phonenumber_txt.Text = selectedRow.Cells[6].Value.ToString();
            address_txt.Text = selectedRow.Cells[7].Value.ToString();

            if (selectedRow.Cells[4].Value.ToString() == "Female") {
                female_rbtn.Checked = true;
            }
            else if (selectedRow.Cells[4].Value.ToString()=="Male") {
                male_rbtn.Checked = true;
            }

          

        }

        private void male_rbtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void female_rbtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }
    }
}
