﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class PaymentForm : Form
    {
        
        Entities db = new Entities();

        public PaymentForm()
        {

            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pay_btn_Click(object sender, EventArgs e)
        {
            int kembalian;
            HeaderTransaction header = db.HeaderTransactions.Where(x => x.UserID == MemberLoginForm.iduser).FirstOrDefault();

            if (payment_txt.Text == "")
            {
                MessageBox.Show("Payment can't be empty!");
            }
            else if (int.Parse(payment_txt.Text) < int.Parse(label11.Text))
            {
                MessageBox.Show("Payment can't be less than total price!");
            }
            else {
                var confirm = MessageBox.Show("Are you sure?", "No", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {

                    //validate change and show
                    //insert purchase details ke header dan detail
                    //update product stock
    


                    {
                        var id_di_db = db.HeaderTransactions.OrderByDescending(a => a.TransactionID).FirstOrDefault();
                        int id;
                        string format;
                        try
                        {
                            id = (Convert.ToInt32(id_di_db.UserID.Substring(id_di_db.TransactionID.Length - 3)));


                        }
                        catch
                        {
                            id = 1;
                        }

                        int nilai = id + 1;

                        format = string.Format("TR{0:d3}", nilai);

                        //untuk nampilin id */
                       
                       kembalian = Convert.ToInt32(payment_txt.Text) - Convert.ToInt32(BuyInstrumentsForm.totalprice);
                        MessageBox.Show("Change:" + Convert.ToString(kembalian));

                        HeaderTransaction headerr = new HeaderTransaction();
                        DetailTransaction detail = new DetailTransaction();
                        MsProduct product = db.MsProducts.Where(x => x.ProductID == BuyInstrumentsForm.productid).FirstOrDefault();

                        //MsType type = new MsType();
                        headerr.TransactionID = format;

                        headerr.UserID = MemberLoginForm.iduser;
                        headerr.TransactionDate = System.DateTime.Today;


                        detail.TransactionID = format;
                        detail.Quantity = BuyInstrumentsForm.quantity;
                        detail.ProductID = BuyInstrumentsForm.productid; 

                        product.ProductStock = product.ProductStock - detail.Quantity;

                        MessageBox.Show("Success");




                        db.HeaderTransactions.Add(headerr);
                        db.DetailTransactions.Add(detail);
                        db.SaveChanges();

                    };


                   
                    
                    MessageBox.Show("Thank you for purchasing!");
                    this.Close();
                }
                else if (confirm == DialogResult.No)
                {


                }
                
            }
        }

        private void PaymentForm_Load(object sender, EventArgs e)
        {
            label7.Text = BuyInstrumentsForm.type;
            label8.Text = BuyInstrumentsForm.name;
            label9.Text = Convert.ToString(BuyInstrumentsForm.price);
            label13.Text = Convert.ToString(BuyInstrumentsForm.quantity);
            label11.Text = Convert.ToString(BuyInstrumentsForm.totalprice);
        }
    }
}
