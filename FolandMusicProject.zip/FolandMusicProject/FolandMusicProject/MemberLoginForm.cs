﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FolandMusicProject
{
    public partial class MemberLoginForm : Form
    {
        public static string iduser;
        public MemberLoginForm()
        {
            InitializeComponent();
        }

        Entities db = new Entities();
        private void MemberLoginForm_Load(object sender, EventArgs e)
        {

        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            string email = email_txt.Text;
            string password = password_txt.Text;

            MsUser user = db.MsUsers.Where(x => x.UserEmail == email && x.UserPassword == password).FirstOrDefault();
            if (email == "" || password == "")
            {
                MessageBox.Show("Email or Password can't be empty");
            }


            else if (email != "" || password != "")

            {
                if (user == null)
                {
                    MessageBox.Show("Incorret Email or Password");
                    email_txt.ResetText();
                    password_txt.ResetText();
                }

                if (user != null)
                {
                    iduser = user.UserID;
                    MessageBox.Show("Login Success");
                    this.Hide();
                    MemberForm member = new MemberForm();
                    Staff staff = new Staff();
                    if (user.UserRole == "Member") {
                        member.Show();
                    }
                    if (user.UserRole == "Staff") {
                        staff.Show();
                    }

                }
            } 
        }
    }
}
