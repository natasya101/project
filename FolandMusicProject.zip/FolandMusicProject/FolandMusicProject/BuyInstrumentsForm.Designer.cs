﻿namespace FolandMusicProject
{
    partial class BuyInstrumentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.type_txt = new System.Windows.Forms.TextBox();
            this.stock_txt = new System.Windows.Forms.TextBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.price_txt = new System.Windows.Forms.TextBox();
            this.totalprice_txt = new System.Windows.Forms.TextBox();
            this.qty_nud = new System.Windows.Forms.NumericUpDown();
            this.instrumentdetails_gb = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.purchase_gb = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.purchase_btn = new System.Windows.Forms.Button();
            this.instruments_dgv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.qty_nud)).BeginInit();
            this.instrumentdetails_gb.SuspendLayout();
            this.purchase_gb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instruments_dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Stock";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(195, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "pcs";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Quantity";
            // 
            // type_txt
            // 
            this.type_txt.Enabled = false;
            this.type_txt.Location = new System.Drawing.Point(135, 41);
            this.type_txt.Name = "type_txt";
            this.type_txt.Size = new System.Drawing.Size(138, 26);
            this.type_txt.TabIndex = 6;
            // 
            // stock_txt
            // 
            this.stock_txt.Enabled = false;
            this.stock_txt.Location = new System.Drawing.Point(135, 174);
            this.stock_txt.Name = "stock_txt";
            this.stock_txt.Size = new System.Drawing.Size(100, 26);
            this.stock_txt.TabIndex = 7;
            // 
            // name_txt
            // 
            this.name_txt.Enabled = false;
            this.name_txt.Location = new System.Drawing.Point(135, 84);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(218, 26);
            this.name_txt.TabIndex = 8;
            // 
            // price_txt
            // 
            this.price_txt.Enabled = false;
            this.price_txt.Location = new System.Drawing.Point(135, 128);
            this.price_txt.Name = "price_txt";
            this.price_txt.Size = new System.Drawing.Size(218, 26);
            this.price_txt.TabIndex = 9;
            // 
            // totalprice_txt
            // 
            this.totalprice_txt.Enabled = false;
            this.totalprice_txt.Location = new System.Drawing.Point(129, 134);
            this.totalprice_txt.Name = "totalprice_txt";
            this.totalprice_txt.Size = new System.Drawing.Size(175, 26);
            this.totalprice_txt.TabIndex = 10;
            // 
            // qty_nud
            // 
            this.qty_nud.Location = new System.Drawing.Point(111, 32);
            this.qty_nud.Name = "qty_nud";
            this.qty_nud.Size = new System.Drawing.Size(74, 26);
            this.qty_nud.TabIndex = 11;
            this.qty_nud.ValueChanged += new System.EventHandler(this.qty_nud_ValueChanged_1);
            // 
            // instrumentdetails_gb
            // 
            this.instrumentdetails_gb.Controls.Add(this.label8);
            this.instrumentdetails_gb.Controls.Add(this.label1);
            this.instrumentdetails_gb.Controls.Add(this.label2);
            this.instrumentdetails_gb.Controls.Add(this.label3);
            this.instrumentdetails_gb.Controls.Add(this.label4);
            this.instrumentdetails_gb.Controls.Add(this.type_txt);
            this.instrumentdetails_gb.Controls.Add(this.name_txt);
            this.instrumentdetails_gb.Controls.Add(this.stock_txt);
            this.instrumentdetails_gb.Controls.Add(this.price_txt);
            this.instrumentdetails_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.instrumentdetails_gb.Location = new System.Drawing.Point(12, 307);
            this.instrumentdetails_gb.Name = "instrumentdetails_gb";
            this.instrumentdetails_gb.Size = new System.Drawing.Size(379, 253);
            this.instrumentdetails_gb.TabIndex = 12;
            this.instrumentdetails_gb.TabStop = false;
            this.instrumentdetails_gb.Text = "Instrument Details";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(250, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "pcs";
            // 
            // purchase_gb
            // 
            this.purchase_gb.Controls.Add(this.label9);
            this.purchase_gb.Controls.Add(this.label7);
            this.purchase_gb.Controls.Add(this.label6);
            this.purchase_gb.Controls.Add(this.label5);
            this.purchase_gb.Controls.Add(this.totalprice_txt);
            this.purchase_gb.Controls.Add(this.qty_nud);
            this.purchase_gb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.purchase_gb.ForeColor = System.Drawing.Color.White;
            this.purchase_gb.Location = new System.Drawing.Point(397, 307);
            this.purchase_gb.Name = "purchase_gb";
            this.purchase_gb.Size = new System.Drawing.Size(327, 198);
            this.purchase_gb.TabIndex = 13;
            this.purchase_gb.TabStop = false;
            this.purchase_gb.Text = "Purchase";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(88, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 25);
            this.label9.TabIndex = 13;
            this.label9.Text = "Total Price";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(89, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Rp.";
            // 
            // purchase_btn
            // 
            this.purchase_btn.BackColor = System.Drawing.Color.BurlyWood;
            this.purchase_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.purchase_btn.ForeColor = System.Drawing.Color.White;
            this.purchase_btn.Location = new System.Drawing.Point(397, 511);
            this.purchase_btn.Name = "purchase_btn";
            this.purchase_btn.Size = new System.Drawing.Size(327, 49);
            this.purchase_btn.TabIndex = 13;
            this.purchase_btn.Text = "Purchase";
            this.purchase_btn.UseVisualStyleBackColor = false;
            this.purchase_btn.Click += new System.EventHandler(this.purchase_btn_Click);
            // 
            // instruments_dgv
            // 
            this.instruments_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.instruments_dgv.Location = new System.Drawing.Point(16, 12);
            this.instruments_dgv.Name = "instruments_dgv";
            this.instruments_dgv.RowTemplate.Height = 24;
            this.instruments_dgv.Size = new System.Drawing.Size(712, 276);
            this.instruments_dgv.TabIndex = 14;
            this.instruments_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.instruments_dgv_CellContentClick);
            // 
            // BuyInstrumentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(755, 584);
            this.Controls.Add(this.instrumentdetails_gb);
            this.Controls.Add(this.purchase_gb);
            this.Controls.Add(this.instruments_dgv);
            this.Controls.Add(this.purchase_btn);
            this.Name = "BuyInstrumentsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foland Music - Buy Instrument";
            this.Load += new System.EventHandler(this.BuyInstrumentsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.qty_nud)).EndInit();
            this.instrumentdetails_gb.ResumeLayout(false);
            this.instrumentdetails_gb.PerformLayout();
            this.purchase_gb.ResumeLayout(false);
            this.purchase_gb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.instruments_dgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox type_txt;
        private System.Windows.Forms.TextBox stock_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox price_txt;
        private System.Windows.Forms.TextBox totalprice_txt;
        private System.Windows.Forms.NumericUpDown qty_nud;
        private System.Windows.Forms.GroupBox instrumentdetails_gb;
        private System.Windows.Forms.GroupBox purchase_gb;
        private System.Windows.Forms.Button purchase_btn;
        private System.Windows.Forms.DataGridView instruments_dgv;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
    }
}